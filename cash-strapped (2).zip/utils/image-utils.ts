/**
 * Utility functions for image handling across the website
 */

// Default image quality setting for the site
export const DEFAULT_IMAGE_QUALITY = 85

// Function to get a fallback image URL if the original fails to load
export function getFallbackImageUrl(category?: string): string {
  // Category-specific fallback images
  if (category) {
    const lowerCategory = category.toLowerCase()
    if (lowerCategory.includes("rap") || lowerCategory.includes("battle")) {
      return "/images/fallbacks/rap-battle-fallback.png"
    }
    if (lowerCategory.includes("dj")) {
      return "/images/fallbacks/dj-fallback.png"
    }
    if (lowerCategory.includes("dance")) {
      return "/images/fallbacks/dance-fallback.png"
    }
    if (lowerCategory.includes("producer")) {
      return "/images/fallbacks/producer-fallback.png"
    }
  }

  // Default fallback
  return "/images/fallbacks/default-fallback.png"
}

// Function to determine appropriate sizes attribute for responsive images
export function getResponsiveSizes(type: "hero" | "card" | "profile" | "background" | "thumbnail"): string {
  switch (type) {
    case "hero":
      return "100vw"
    case "card":
      return "(max-width: 640px) 100vw, (max-width: 768px) 50vw, (max-width: 1024px) 33vw, 25vw"
    case "profile":
      return "(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw"
    case "background":
      return "100vw"
    case "thumbnail":
      return "(max-width: 640px) 25vw, 10vw"
    default:
      return "100vw"
  }
}

// Function to check if an image URL is valid (not a placeholder)
export function isValidImageUrl(url: string): boolean {
  if (!url) return false
  return !url.includes("placeholder.svg")
}
