"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { CalendarIcon, List, MapPin, Filter, Search, X } from "lucide-react"
import { AnimatedBackground } from "@/components/ui/animated-background"
import { ScheduleCalendarView } from "@/components/schedule/schedule-calendar-view"
import { ScheduleListView } from "@/components/schedule/schedule-list-view"
import { EventFilters } from "@/components/schedule/event-filters"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useSoundContext } from "@/components/sound-provider"
import { cn } from "@/lib/utils"
import { SCHEDULE_DATA, type ScheduleEvent } from "@/data/schedule-data"

type ViewMode = "calendar" | "list"

export default function SchedulePage() {
  const [viewMode, setViewMode] = useState<ViewMode>("calendar")
  const [events, setEvents] = useState<ScheduleEvent[]>(SCHEDULE_DATA)
  const [filteredEvents, setFilteredEvents] = useState<ScheduleEvent[]>(SCHEDULE_DATA)
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [selectedCity, setSelectedCity] = useState<string>("all")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [isLoading, setIsLoading] = useState(true)
  const { playSound } = useSoundContext()

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Filter events based on search query and filters
  useEffect(() => {
    let filtered = [...events]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (event) =>
          event.title.toLowerCase().includes(query) ||
          event.city.toLowerCase().includes(query) ||
          event.venue.toLowerCase().includes(query),
      )
    }

    // Apply city filter
    if (selectedCity !== "all") {
      filtered = filtered.filter((event) => event.city === selectedCity)
    }

    // Apply category filter
    if (selectedCategory !== "all") {
      filtered = filtered.filter((event) => event.category === selectedCategory)
    }

    setFilteredEvents(filtered)
  }, [events, searchQuery, selectedCity, selectedCategory])

  // Toggle view mode
  const toggleViewMode = (mode: ViewMode) => {
    if (mode !== viewMode) {
      playSound("click")
      setViewMode(mode)
    }
  }

  // Reset all filters
  const resetFilters = () => {
    playSound("click")
    setSearchQuery("")
    setSelectedCity("all")
    setSelectedCategory("all")
  }

  // Get unique cities for filter
  const cities = ["all", ...Array.from(new Set(events.map((event) => event.city)))]

  // Get unique categories for filter
  const categories = ["all", ...Array.from(new Set(events.map((event) => event.category)))]

  return (
    <div className="relative min-h-screen">
      {/* Animated Background */}
      <AnimatedBackground />

      <div className="container mx-auto px-4 py-12 md:py-16">
        {/* Page Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="title-font text-4xl md:text-5xl lg:text-6xl mb-4 gold-text-gradient">EVENT SCHEDULE</h1>
          <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto">
            Find and book your tickets for upcoming CA$H STRAPPED events across the UK. Don't miss your chance to
            experience the ultimate talent roadshow live!
          </p>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden">
            <div className="p-4 flex flex-col md:flex-row gap-4">
              {/* Search Input */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search events, cities or venues..."
                  className="pl-10 bg-black/50 border-gold/30 focus:border-gold rounded-lg"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                {searchQuery && (
                  <button
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gold/60 hover:text-gold"
                    onClick={() => setSearchQuery("")}
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>

              {/* View Toggle */}
              <div className="flex items-center bg-black/50 rounded-lg border border-gold/30 p-1">
                <button
                  className={cn(
                    "flex items-center justify-center px-3 py-2 rounded-md transition-colors",
                    viewMode === "calendar"
                      ? "bg-gold text-black font-medium"
                      : "text-gold/70 hover:text-gold hover:bg-gold/10",
                  )}
                  onClick={() => toggleViewMode("calendar")}
                >
                  <CalendarIcon className="w-4 h-4 mr-2" />
                  <span className="hidden sm:inline">Calendar</span>
                </button>
                <button
                  className={cn(
                    "flex items-center justify-center px-3 py-2 rounded-md transition-colors",
                    viewMode === "list"
                      ? "bg-gold text-black font-medium"
                      : "text-gold/70 hover:text-gold hover:bg-gold/10",
                  )}
                  onClick={() => toggleViewMode("list")}
                >
                  <List className="w-4 h-4 mr-2" />
                  <span className="hidden sm:inline">List</span>
                </button>
              </div>

              {/* Filter Button */}
              <button
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors",
                  showFilters
                    ? "bg-gold/10 border-gold/50 text-gold"
                    : "border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                )}
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-4 w-4" />
                <span>Filters</span>
                {(selectedCity !== "all" || selectedCategory !== "all") && (
                  <span className="inline-flex items-center justify-center w-5 h-5 text-xs bg-gold text-black rounded-full">
                    {(selectedCity !== "all" ? 1 : 0) + (selectedCategory !== "all" ? 1 : 0)}
                  </span>
                )}
              </button>
            </div>

            {/* Expanded Filters */}
            {showFilters && (
              <EventFilters
                cities={cities}
                categories={categories}
                selectedCity={selectedCity}
                selectedCategory={selectedCategory}
                onCityChange={setSelectedCity}
                onCategoryChange={setSelectedCategory}
                onReset={resetFilters}
              />
            )}
          </div>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {isLoading ? (
            // Loading state
            <div className="flex justify-center items-center py-20">
              <div className="w-16 h-16 border-4 border-gold/30 border-t-gold rounded-full animate-spin"></div>
            </div>
          ) : filteredEvents.length > 0 ? (
            // Events display
            viewMode === "calendar" ? (
              <ScheduleCalendarView events={filteredEvents} />
            ) : (
              <ScheduleListView events={filteredEvents} />
            )
          ) : (
            // No events found
            <div className="text-center py-20 bg-black/40 backdrop-blur-md rounded-xl border border-gold/20">
              <MapPin className="h-12 w-12 text-gold/50 mx-auto mb-4" />
              <h3 className="text-gold text-xl mb-2">No Events Found</h3>
              <p className="text-white/70 mb-6">No events match your current search or filters.</p>
              <Button className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium" onClick={resetFilters}>
                Reset Filters
              </Button>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}
