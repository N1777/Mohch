"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useSoundContext } from "@/components/sound-provider"
import { useToast } from "@/components/ui/use-toast"
import { Star, TrendingUp, Search, Filter, Mic, Music, Users, Sparkles, Trophy, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { EnhancedVoteCard } from "@/components/ui/enhanced-vote-card"
import { VotingStats } from "@/components/ui/voting-stats"
import { VoteRegistrationModal, type RegistrationData } from "@/components/ui/vote-registration-modal"
import { AnimatedBackground } from "@/components/ui/animated-background"
import { CategoryShowcase } from "@/components/ui/category-showcase"
import { Leaderboard } from "@/components/ui/leaderboard"
import { cn } from "@/lib/utils"

// Mock data for contestants with trending and featured flags
const ALL_CONTESTANTS = [
  {
    id: 1,
    name: "Lyrical Beast",
    category: "Rap Battle",
    city: "Leicester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1243,
    videoUrl: "/videos/contestant1.mp4",
    trending: true,
    featured: true,
  },
  {
    id: 2,
    name: "DJ Spinmaster",
    category: "DJ Competition",
    city: "London",
    image: "/placeholder.svg?height=400&width=600",
    votes: 982,
    videoUrl: "/videos/contestant2.mp4",
  },
  {
    id: 3,
    name: "Flow Queen",
    category: "Rap Battle",
    city: "Manchester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1567,
    videoUrl: "/videos/contestant3.mp4",
    trending: true,
  },
  {
    id: 4,
    name: "Rhythm Crew",
    category: "Dance Crew",
    city: "Birmingham",
    image: "/placeholder.svg?height=400&width=600",
    votes: 2103,
    videoUrl: "/videos/contestant4.mp4",
    featured: true,
  },
  {
    id: 5,
    name: "Beat Maker",
    category: "Producer",
    city: "Bristol",
    image: "/placeholder.svg?height=400&width=600",
    votes: 876,
    videoUrl: "/videos/contestant5.mp4",
  },
  {
    id: 6,
    name: "Verse Master",
    category: "Rap Battle",
    city: "Leeds",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1432,
    videoUrl: "/videos/contestant6.mp4",
  },
  {
    id: 7,
    name: "DJ Scratch",
    category: "DJ Competition",
    city: "Sheffield",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1089,
    videoUrl: "/videos/contestant7.mp4",
    trending: true,
  },
  {
    id: 8,
    name: "Street Moves",
    category: "Dance Crew",
    city: "Nottingham",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1765,
    videoUrl: "/videos/contestant8.mp4",
  },
]

// Category definitions with icons
const CATEGORIES = [
  {
    id: "all",
    name: "All Categories",
    icon: <Sparkles className="w-5 h-5" />,
    count: ALL_CONTESTANTS.length,
  },
  {
    id: "Rap Battle",
    name: "Rap Battles",
    icon: <Mic className="w-5 h-5" />,
    count: ALL_CONTESTANTS.filter((c) => c.category === "Rap Battle").length,
  },
  {
    id: "DJ Competition",
    name: "DJ Sets",
    icon: <Music className="w-5 h-5" />,
    count: ALL_CONTESTANTS.filter((c) => c.category === "DJ Competition").length,
  },
  {
    id: "Dance Crew",
    name: "Dance Crews",
    icon: <Users className="w-5 h-5" />,
    count: ALL_CONTESTANTS.filter((c) => c.category === "Dance Crew").length,
  },
  {
    id: "Producer",
    name: "Producers",
    icon: <Music className="w-5 h-5" />,
    count: ALL_CONTESTANTS.filter((c) => c.category === "Producer").length,
  },
]

// City options
const CITIES = [
  { value: "all", label: "All Cities" },
  { value: "Leicester", label: "Leicester" },
  { value: "London", label: "London" },
  { value: "Manchester", label: "Manchester" },
  { value: "Birmingham", label: "Birmingham" },
  { value: "Bristol", label: "Bristol" },
  { value: "Leeds", label: "Leeds" },
  { value: "Sheffield", label: "Sheffield" },
  { value: "Nottingham", label: "Nottingham" },
]

export default function VotePage() {
  // State
  const [contestants, setContestants] = useState(ALL_CONTESTANTS)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [cityFilter, setCityFilter] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false)
  const [isRegistered, setIsRegistered] = useState(false)
  const [votesRemaining, setVotesRemaining] = useState(3)
  const [totalVotes, setTotalVotes] = useState(ALL_CONTESTANTS.reduce((sum, contestant) => sum + contestant.votes, 0))
  const [isLoading, setIsLoading] = useState(true)

  const { playSound } = useSoundContext()
  const { toast } = useToast()

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Handle voting
  const handleVote = (id: number) => {
    if (votesRemaining <= 0) {
      toast({
        title: "No votes remaining",
        description: "You've used all your votes for today. Come back tomorrow for more!",
        variant: "destructive",
      })
      return
    }

    if (!isRegistered) {
      setIsRegistrationOpen(true)
      return
    }

    playSound("applause")

    // Update contestant votes
    setContestants((prev) =>
      prev.map((contestant) => (contestant.id === id ? { ...contestant, votes: contestant.votes + 1 } : contestant)),
    )

    // Update total votes
    setTotalVotes((prev) => prev + 1)

    // Decrease remaining votes
    setVotesRemaining((prev) => prev - 1)

    toast({
      title: "Vote Recorded!",
      description: `You have ${votesRemaining - 1} votes remaining today.`,
    })
  }

  // Handle registration
  const handleRegister = (data: RegistrationData) => {
    setIsRegistered(true)

    toast({
      title: "Registration Successful!",
      description: "You can now vote for your favorite contestants.",
    })

    playSound("click")
  }

  // Filter contestants
  const filteredContestants = ALL_CONTESTANTS.filter((contestant) => {
    const matchesSearch = contestant.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || contestant.category === categoryFilter
    const matchesCity = cityFilter === "all" || contestant.city === cityFilter

    return matchesSearch && matchesCategory && matchesCity
  })

  // Get featured contestants
  const featuredContestants = filteredContestants.filter((c) => c.featured)

  // Get trending contestants
  const trendingContestants = filteredContestants.filter((c) => c.trending)

  // Get regular contestants (not featured or trending)
  const regularContestants = filteredContestants.filter((c) => !c.featured && !c.trending)

  return (
    <div className="relative">
      {/* Animated Background */}
      <AnimatedBackground />

      {/* Main Content */}
      <div className="py-12 md:py-16 container mx-auto px-4">
        {/* Hero Section */}
        <motion.div
          className="text-center mb-10"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="title-font text-4xl md:text-5xl lg:text-6xl mb-4 gold-text-gradient">
            VOTE & DECIDE THE WINNER
          </h1>
          <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto mb-6">
            Your votes determine who takes home the £50,000 prize! Vote daily to support your favorites.
          </p>

          {isRegistered ? (
            <div className="inline-flex items-center bg-gold/10 px-5 py-3 rounded-full border border-gold/30">
              <Star className="text-gold h-5 w-5 mr-2" />
              <span className="text-gold font-medium">You have {votesRemaining} votes remaining today</span>
            </div>
          ) : (
            <Button
              className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-6 px-8 rounded-full animate-pulse"
              onClick={() => setIsRegistrationOpen(true)}
            >
              Register to Start Voting
            </Button>
          )}
        </motion.div>

        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Stats and Leaderboard */}
          <div className="lg:col-span-1 space-y-6">
            {/* Voting Stats */}
            <VotingStats
              totalVotes={totalVotes}
              remainingVotes={votesRemaining}
              isRegistered={isRegistered}
              daysLeft={21}
              totalContestants={ALL_CONTESTANTS.length}
            />

            {/* Leaderboard */}
            <Leaderboard contestants={ALL_CONTESTANTS} />

            {/* How Voting Works - Mobile Only */}
            <div className="lg:hidden">
              <motion.div
                className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="p-5">
                  <h3 className="text-gold title-font text-xl mb-4">How Voting Works</h3>

                  <div className="space-y-3">
                    <div className="bg-black/50 rounded-lg p-4 border border-gold/10">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center">
                          <span className="text-gold font-bold">1</span>
                        </div>
                        <h4 className="text-gold font-medium">Register</h4>
                      </div>
                      <p className="text-white/70 text-sm">
                        Create an account to unlock your daily votes and receive exclusive updates.
                      </p>
                    </div>

                    <div className="bg-black/50 rounded-lg p-4 border border-gold/10">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center">
                          <span className="text-gold font-bold">2</span>
                        </div>
                        <h4 className="text-gold font-medium">Vote Daily</h4>
                      </div>
                      <p className="text-white/70 text-sm">
                        You get 3 votes per day. Use them wisely to support your favorite contestants.
                      </p>
                    </div>

                    <div className="bg-black/50 rounded-lg p-4 border border-gold/10">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center">
                          <span className="text-gold font-bold">3</span>
                        </div>
                        <h4 className="text-gold font-medium">Win Prizes</h4>
                      </div>
                      <p className="text-white/70 text-sm">
                        Active voters are entered into weekly prize draws for exclusive merchandise and event tickets.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Right Column - Contestants */}
          <div className="lg:col-span-2 space-y-8">
            {/* Search and Filters */}
            <div className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden">
              <div className="p-4 flex items-center gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
                  <Input
                    type="text"
                    placeholder="Search contestants..."
                    className="pl-10 bg-black/50 border-gold/30 focus:border-gold rounded-lg"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  {searchTerm && (
                    <button
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gold/60 hover:text-gold"
                      onClick={() => setSearchTerm("")}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>

                <button
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors",
                    showFilters
                      ? "bg-gold/10 border-gold/50 text-gold"
                      : "border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                  )}
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="h-4 w-4" />
                  <span className="hidden sm:inline">Filters</span>
                  {cityFilter !== "all" && (
                    <span className="inline-flex items-center justify-center w-5 h-5 text-xs bg-gold text-black rounded-full">
                      1
                    </span>
                  )}
                </button>
              </div>

              {/* City Filters */}
              {showFilters && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="px-4 pb-4 border-t border-gold/10"
                >
                  <div className="pt-4">
                    <label className="block text-gold/80 text-sm mb-2">City</label>
                    <div className="flex flex-wrap gap-2">
                      {CITIES.map((city) => (
                        <button
                          key={city.value}
                          className={cn(
                            "px-3 py-1.5 rounded-full text-sm transition-colors",
                            cityFilter === city.value
                              ? "bg-gold text-black font-medium"
                              : "bg-black/50 border border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                          )}
                          onClick={() => setCityFilter(city.value)}
                        >
                          {city.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Reset Filters */}
                  {cityFilter !== "all" && (
                    <div className="mt-4 flex justify-end">
                      <button
                        className="text-gold/70 hover:text-gold text-sm flex items-center gap-1"
                        onClick={() => setCityFilter("all")}
                      >
                        <X className="h-3 w-3" />
                        Reset filters
                      </button>
                    </div>
                  )}
                </motion.div>
              )}
            </div>

            {/* Category Showcase */}
            <div className="mb-6">
              <CategoryShowcase
                categories={CATEGORIES}
                selectedCategory={categoryFilter}
                onSelect={setCategoryFilter}
              />
            </div>

            {/* Featured Contestants */}
            {featuredContestants.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center mb-4">
                  <Trophy className="text-gold h-5 w-5 mr-2" />
                  <h2 className="title-font text-2xl text-gold">Featured Contestants</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {featuredContestants.map((contestant, index) => (
                    <motion.div
                      key={contestant.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <EnhancedVoteCard
                        contestant={contestant}
                        onVote={handleVote}
                        isRegistered={isRegistered}
                        showRegistrationModal={() => setIsRegistrationOpen(true)}
                        disabled={votesRemaining <= 0}
                        variant="featured"
                      />
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* Trending Contestants */}
            {trendingContestants.length > 0 && (
              <div className="mb-8">
                <div className="flex items-center mb-4">
                  <TrendingUp className="text-gold h-5 w-5 mr-2" />
                  <h2 className="title-font text-2xl text-gold">Trending Now</h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {trendingContestants.map((contestant, index) => (
                    <motion.div
                      key={contestant.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <EnhancedVoteCard
                        contestant={contestant}
                        onVote={handleVote}
                        isRegistered={isRegistered}
                        showRegistrationModal={() => setIsRegistrationOpen(true)}
                        disabled={votesRemaining <= 0}
                      />
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* All Other Contestants */}
            {regularContestants.length > 0 ? (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="title-font text-2xl text-gold">
                    {categoryFilter === "all" ? "All Contestants" : categoryFilter}
                  </h2>
                  <p className="text-white/70 text-sm">{regularContestants.length} contestants</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {regularContestants.map((contestant, index) => (
                    <motion.div
                      key={contestant.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <EnhancedVoteCard
                        contestant={contestant}
                        onVote={handleVote}
                        isRegistered={isRegistered}
                        showRegistrationModal={() => setIsRegistrationOpen(true)}
                        disabled={votesRemaining <= 0}
                      />
                    </motion.div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-16 bg-black/40 backdrop-blur-md rounded-xl border border-gold/20">
                <p className="text-gold/80 text-xl mb-4">No contestants found matching your filters.</p>
                <Button
                  className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium"
                  onClick={() => {
                    setSearchTerm("")
                    setCategoryFilter("all")
                    setCityFilter("all")
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* How Voting Works - Desktop Only */}
        <div className="hidden lg:block mt-16">
          <motion.div
            className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="p-6">
              <h2 className="title-font text-2xl text-gold mb-6">How Voting Works</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-black/50 rounded-lg p-5 border border-gold/10 relative overflow-hidden">
                  <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full bg-gold/5"></div>
                  <div className="relative z-10">
                    <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                      <span className="text-gold title-font text-xl">1</span>
                    </div>
                    <h3 className="text-gold text-xl mb-2">Register</h3>
                    <p className="text-white/70">
                      Create an account to unlock your daily votes and receive exclusive updates.
                    </p>
                  </div>
                </div>

                <div className="bg-black/50 rounded-lg p-5 border border-gold/10 relative overflow-hidden">
                  <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full bg-gold/5"></div>
                  <div className="relative z-10">
                    <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                      <span className="text-gold title-font text-xl">2</span>
                    </div>
                    <h3 className="text-gold text-xl mb-2">Vote Daily</h3>
                    <p className="text-white/70">
                      You get 3 votes per day. Use them wisely to support your favorite contestants.
                    </p>
                  </div>
                </div>

                <div className="bg-black/50 rounded-lg p-5 border border-gold/10 relative overflow-hidden">
                  <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full bg-gold/5"></div>
                  <div className="relative z-10">
                    <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center mb-4">
                      <span className="text-gold title-font text-xl">3</span>
                    </div>
                    <h3 className="text-gold text-xl mb-2">Win Prizes</h3>
                    <p className="text-white/70">
                      Active voters are entered into weekly prize draws for exclusive merchandise and event tickets.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Registration Modal */}
      <VoteRegistrationModal
        isOpen={isRegistrationOpen}
        onClose={() => setIsRegistrationOpen(false)}
        onRegister={handleRegister}
      />
    </div>
  )
}
