import { Suspense } from "react"
import dynamic from "next/dynamic"
import EventInfo from "@/components/event-info"
import FeaturedContestants from "@/components/featured-contestants"
import UploadSection from "@/components/upload-section"
import HeroCarouselFallback from "@/components/hero-carousel-fallback"
import PromotionalSection from "@/components/promotional-section"

// Dynamically import the hero carousel with images
const HeroCarousel = dynamic(() => import("@/components/hero-carousel"), {
  ssr: false,
  loading: () => <HeroCarouselFallback />,
})

export default function Home() {
  return (
    <div>
      <Suspense fallback={<HeroCarouselFallback />}>
        <HeroCarousel />
      </Suspense>
      <PromotionalSection />
      <EventInfo />
      <FeaturedContestants />
      <UploadSection />
    </div>
  )
}
