// This file is used to preload critical images on the server side
import { NextResponse } from "next/server"

export async function GET() {
  // List of critical images to preload
  const criticalImages = [
    "/images/leicester-background.png",
    "/images/hall-of-fame-stage.png",
    "/images/premium-gold-trophy-cash.jpg",
    "/images/fallbacks/default-fallback.png",
    "/images/fallbacks/rap-battle-fallback.png",
    "/images/fallbacks/dj-fallback.png",
    "/images/fallbacks/dance-fallback.png",
    "/images/fallbacks/producer-fallback.png",
  ]

  return NextResponse.json({
    images: criticalImages,
    status: "success",
  })
}
