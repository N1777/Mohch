"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { useParams, notFound } from "next/navigation"
import { Calendar, Clock, MapPin, Ticket, ArrowLeft, Star, Music, Users, Mic } from "lucide-react"
import { OptimizedImage } from "@/components/ui/optimized-image"
import { AnimatedBackground } from "@/components/ui/animated-background"
import { useSoundContext } from "@/components/sound-provider"
import Link from "next/link"

// City data
const CITY_DATA = {
  leicester: {
    name: "Leicester",
    venue: "Curve Theatre",
    address: "60 Rutland Street, Leicester, LE1 1SB",
    date: "15.06.2025",
    time: "19:00",
    ticketsUrl: "/tickets/leicester",
    available: true,
    featured: true,
    upcoming: true,
    image: "/placeholder.svg?height=600&width=1200",
    venueImage: "/placeholder.svg?height=600&width=1200",
    mapUrl: "https://maps.google.com/?q=Curve+Theatre+Leicester",
    description:
      "Leicester's Curve Theatre hosts our tour opening night! Experience the kickoff of CA$H STRAPPED with special guest performances, exclusive opening night content, and the first chance to see this season's contestants live on stage.",
    performers: [
      { name: "Lyrical Beast", category: "Rap Battle", image: "/placeholder.svg?height=400&width=600" },
      { name: "DJ Spinmaster", category: "DJ Competition", image: "/placeholder.svg?height=400&width=600" },
      { name: "Flow Queen", category: "Rap Battle", image: "/placeholder.svg?height=400&width=600" },
      { name: "Rhythm Crew", category: "Dance Crew", image: "/placeholder.svg?height=400&width=600" },
    ],
    schedule: [
      { time: "18:00", event: "Doors Open" },
      { time: "19:00", event: "Opening Act" },
      { time: "19:30", event: "DJ Competition" },
      { time: "20:15", event: "Intermission" },
      { time: "20:45", event: "Rap Battles" },
      { time: "21:30", event: "Dance Crew Performances" },
      { time: "22:15", event: "Audience Voting" },
      { time: "22:45", event: "Results & Closing" },
    ],
  },
  london: {
    name: "London",
    venue: "O2 Academy Brixton",
    address: "211 Stockwell Rd, London SW9 9SL",
    date: "22.06.2025",
    time: "19:30",
    ticketsUrl: "/tickets/london",
    available: true,
    featured: false,
    upcoming: false,
    image: "/placeholder.svg?height=600&width=1200",
    venueImage: "/placeholder.svg?height=600&width=1200",
    mapUrl: "https://maps.google.com/?q=O2+Academy+Brixton+London",
    description:
      "The iconic O2 Academy Brixton hosts our London show, bringing together the capital's finest talent alongside our touring contestants. Expect special guest appearances and a night of unforgettable performances.",
    performers: [
      { name: "Lyrical Beast", category: "Rap Battle", image: "/placeholder.svg?height=400&width=600" },
      { name: "DJ Spinmaster", category: "DJ Competition", image: "/placeholder.svg?height=400&width=600" },
      { name: "Flow Queen", category: "Rap Battle", image: "/placeholder.svg?height=400&width=600" },
      { name: "Rhythm Crew", category: "Dance Crew", image: "/placeholder.svg?height=400&width=600" },
    ],
    schedule: [
      { time: "18:30", event: "Doors Open" },
      { time: "19:30", event: "Opening Act" },
      { time: "20:00", event: "DJ Competition" },
      { time: "20:45", event: "Intermission" },
      { time: "21:15", event: "Rap Battles" },
      { time: "22:00", event: "Dance Crew Performances" },
      { time: "22:45", event: "Audience Voting" },
      { time: "23:15", event: "Results & Closing" },
    ],
  },
  // Add more cities as needed
}

type CityKey = keyof typeof CITY_DATA

export default function CityTourPage() {
  const params = useParams()
  const { playSound } = useSoundContext()
  const [cityData, setCityData] = useState<(typeof CITY_DATA)[CityKey] | null>(null)

  useEffect(() => {
    const citySlug = params.city as string

    if (citySlug in CITY_DATA) {
      setCityData(CITY_DATA[citySlug as CityKey])
    } else {
      notFound()
    }
  }, [params.city])

  if (!cityData) {
    return null // Loading state
  }

  return (
    <div className="relative">
      {/* Animated Background */}
      <AnimatedBackground />

      {/* Hero Section */}
      <section className="relative min-h-[50vh] flex items-center py-16 md:py-24 overflow-hidden">
        {/* Background image */}
        <div className="absolute inset-0 z-0">
          <OptimizedImage
            src={cityData.image}
            alt={`${cityData.name} - CA$H STRAPPED Tour`}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black via-black/80 to-black/90"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <Link
            href="/tour"
            className="inline-flex items-center text-gold/80 hover:text-gold mb-8"
            onClick={() => playSound("click")}
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to Tour Schedule
          </Link>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
              <div>
                {cityData.featured && (
                  <div className="inline-flex items-center bg-gold/10 px-3 py-1 rounded-full text-gold text-sm mb-4">
                    <Star className="w-4 h-4 mr-2" />
                    <span>Featured Event</span>
                  </div>
                )}

                <h1 className="title-font text-4xl md:text-5xl lg:text-6xl text-gold mb-2">{cityData.name}</h1>

                <div className="flex items-center text-white/80 mb-4">
                  <MapPin className="w-5 h-5 mr-2 text-gold/80" />
                  <span>{cityData.venue}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 items-center">
                <div className="bg-black/50 backdrop-blur-sm px-4 py-3 rounded-lg border border-gold/20">
                  <div className="text-gold/80 text-sm">Date & Time</div>
                  <div className="flex items-center gap-3 mt-1">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1 text-gold" />
                      <span className="text-white">{cityData.date}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1 text-gold" />
                      <span className="text-white">{cityData.time}</span>
                    </div>
                  </div>
                </div>

                <a
                  href={cityData.ticketsUrl}
                  className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-3 px-6 rounded-lg flex items-center"
                  onClick={() => playSound("click")}
                >
                  <Ticket className="w-5 h-5 mr-2" />
                  Buy Tickets
                </a>
              </div>
            </div>

            <p className="text-white/80 max-w-3xl text-lg">{cityData.description}</p>
          </motion.div>
        </div>
      </section>

      {/* Event Details Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Venue Info */}
            <div className="lg:col-span-1">
              <motion.div
                className="bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 overflow-hidden h-full"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <div className="relative aspect-video">
                  <OptimizedImage src={cityData.venueImage} alt={cityData.venue} fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="text-gold text-xl">{cityData.venue}</h3>
                  </div>
                </div>

                <div className="p-5 space-y-4">
                  <div>
                    <h3 className="text-gold font-medium mb-2">Venue Address</h3>
                    <p className="text-white/70">{cityData.address}</p>
                    <a
                      href={cityData.mapUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gold/80 hover:text-gold text-sm flex items-center mt-2"
                    >
                      <MapPin className="w-4 h-4 mr-1" />
                      View on Google Maps
                    </a>
                  </div>

                  <div>
                    <h3 className="text-gold font-medium mb-2">Event Schedule</h3>
                    <div className="space-y-2">
                      {cityData.schedule.map((item, index) => (
                        <div key={index} className="flex justify-between">
                          <span className="text-gold/80">{item.time}</span>
                          <span className="text-white/70">{item.event}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-gold font-medium mb-2">Venue Facilities</h3>
                    <ul className="text-white/70 space-y-1">
                      <li className="flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-gold mr-2"></span>
                        Wheelchair accessible
                      </li>
                      <li className="flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-gold mr-2"></span>
                        Food and drinks available
                      </li>
                      <li className="flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-gold mr-2"></span>
                        Merchandise stands
                      </li>
                      <li className="flex items-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-gold mr-2"></span>
                        Cloakroom facilities
                      </li>
                    </ul>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Right Column - Performers */}
            <div className="lg:col-span-2">
              <h2 className="title-font text-3xl text-gold mb-6">Featured Performers</h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {cityData.performers.map((performer, index) => (
                  <motion.div
                    key={index}
                    className="bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 overflow-hidden"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <div className="relative aspect-video">
                      <OptimizedImage src={performer.image} alt={performer.name} fill className="object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>

                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <div className="flex items-center">
                          {performer.category === "Rap Battle" ? (
                            <Mic className="w-4 h-4 text-gold mr-2" />
                          ) : performer.category === "DJ Competition" ? (
                            <Music className="w-4 h-4 text-gold mr-2" />
                          ) : (
                            <Users className="w-4 h-4 text-gold mr-2" />
                          )}
                          <span className="text-gold/80 text-sm">{performer.category}</span>
                        </div>
                        <h3 className="text-gold text-xl">{performer.name}</h3>
                      </div>
                    </div>

                    <div className="p-4">
                      <Link
                        href={`/contestants/${performer.name.toLowerCase().replace(/\s+/g, "-")}`}
                        className="w-full py-2 rounded-lg border border-gold/30 text-gold hover:bg-gold/10 flex items-center justify-center gap-2 transition-all"
                      >
                        View Profile
                      </Link>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8">
                <h2 className="title-font text-3xl text-gold mb-6">Event Highlights</h2>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    {
                      icon: <Mic className="w-6 h-6" />,
                      title: "Rap Battles",
                      description: "Witness lyrical warfare as MCs battle head-to-head with their best bars and flows.",
                    },
                    {
                      icon: <Music className="w-6 h-6" />,
                      title: "DJ Competitions",
                      description: "DJs showcase their mixing skills, creativity and crowd control in epic showdowns.",
                    },
                    {
                      icon: <Users className="w-6 h-6" />,
                      title: "Dance Crews",
                      description:
                        "Dance crews battle it out with jaw-dropping choreography and stunning performances.",
                    },
                  ].map((highlight, index) => (
                    <motion.div
                      key={index}
                      className="bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 p-5"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: 0.3 + index * 0.1 }}
                    >
                      <div className="w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center mb-4 text-gold">
                        {highlight.icon}
                      </div>
                      <h3 className="text-gold text-xl mb-2">{highlight.title}</h3>
                      <p className="text-white/70">{highlight.description}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <motion.div
            className="bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="p-8 md:p-12 text-center">
              <h2 className="title-font text-3xl md:text-4xl text-gold mb-4">Secure Your Tickets Now</h2>
              <p className="text-white/80 max-w-2xl mx-auto mb-8">
                Don't miss your chance to experience CA$H STRAPPED live in {cityData.name}. Limited tickets available
                for this exclusive event.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href={cityData.ticketsUrl}
                  className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-4 px-8 rounded-lg flex items-center justify-center gap-2"
                  onClick={() => playSound("click")}
                >
                  <Ticket className="w-5 h-5" />
                  Buy Tickets
                </a>

                <Link
                  href="/tour"
                  className="border border-gold/30 text-gold hover:bg-gold/10 py-4 px-8 rounded-lg flex items-center justify-center gap-2"
                  onClick={() => playSound("click")}
                >
                  <Calendar className="w-5 h-5" />
                  View Full Tour
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
