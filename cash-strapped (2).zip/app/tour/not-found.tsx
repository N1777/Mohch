import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MapPin } from "lucide-react"

export default function TourNotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center">
      <div className="text-center max-w-md mx-auto px-4">
        <div className="w-20 h-20 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-6">
          <MapPin className="w-10 h-10 text-gold" />
        </div>

        <h1 className="title-font text-4xl text-gold mb-4">Location Not Found</h1>

        <p className="text-white/70 mb-8">
          The tour location you're looking for doesn't exist or hasn't been announced yet. Check out our current tour
          schedule for available locations.
        </p>

        <Link href="/tour">
          <Button className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-3 px-6">
            View Tour Schedule
          </Button>
        </Link>
      </div>
    </div>
  )
}
