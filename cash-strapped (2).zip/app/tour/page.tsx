"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Calendar, MapPin, Ticket, Star, ArrowRight } from "lucide-react"
import { InteractiveMap, type TourLocation } from "@/components/ui/interactive-map"
import { TourTimeline } from "@/components/ui/tour-timeline"
import { CityHighlight } from "@/components/ui/city-highlight"
import { TourFaq } from "@/components/ui/tour-faq"
import { TourNewsletter } from "@/components/ui/tour-newsletter"
import { AnimatedBackground } from "@/components/ui/animated-background"
import { Button } from "@/components/ui/button"
import { useSoundContext } from "@/components/sound-provider"
import Link from "next/link"

// Tour location data
const TOUR_LOCATIONS: TourLocation[] = [
  {
    id: "leicester",
    city: "Leicester",
    venue: "Curve Theatre",
    date: "15.06.2025",
    time: "19:00",
    coordinates: { x: 400, y: 300 },
    ticketsUrl: "/tickets/leicester",
    available: true,
    featured: true,
    upcoming: true,
  },
  {
    id: "london",
    city: "London",
    venue: "O2 Academy Brixton",
    date: "22.06.2025",
    time: "19:30",
    coordinates: { x: 450, y: 400 },
    ticketsUrl: "/tickets/london",
    available: true,
  },
  {
    id: "manchester",
    city: "Manchester",
    venue: "Manchester Academy",
    date: "29.06.2025",
    time: "19:00",
    coordinates: { x: 350, y: 250 },
    ticketsUrl: "/tickets/manchester",
    available: true,
  },
  {
    id: "birmingham",
    city: "Birmingham",
    venue: "O2 Academy Birmingham",
    date: "06.07.2025",
    time: "19:30",
    coordinates: { x: 380, y: 320 },
    ticketsUrl: "/tickets/birmingham",
    available: false,
  },
  {
    id: "bristol",
    city: "Bristol",
    venue: "O2 Academy Bristol",
    date: "13.07.2025",
    time: "19:00",
    coordinates: { x: 320, y: 380 },
    ticketsUrl: "/tickets/bristol",
    available: false,
  },
  {
    id: "leeds",
    city: "Leeds",
    venue: "O2 Academy Leeds",
    date: "20.07.2025",
    time: "19:30",
    coordinates: { x: 380, y: 220 },
    ticketsUrl: "/tickets/leeds",
    available: false,
  },
  {
    id: "glasgow",
    city: "Glasgow",
    venue: "O2 Academy Glasgow",
    date: "27.07.2025",
    time: "19:00",
    coordinates: { x: 300, y: 150 },
    ticketsUrl: "/tickets/glasgow",
    available: false,
  },
  {
    id: "newcastle",
    city: "Newcastle",
    venue: "O2 City Hall Newcastle",
    date: "03.08.2025",
    time: "19:30",
    coordinates: { x: 380, y: 180 },
    ticketsUrl: "/tickets/newcastle",
    available: false,
  },
]

// FAQ data
const FAQS = [
  {
    question: "What time do doors open?",
    answer:
      "Doors typically open 1 hour before the event start time. Please check your ticket for specific information as this may vary by venue.",
  },
  {
    question: "Are there age restrictions?",
    answer:
      "CA$H STRAPPED events are generally 16+ or 18+ depending on the venue. Please check the specific event details for age restrictions. Valid ID will be required.",
  },
  {
    question: "Can I get a refund if I can't attend?",
    answer:
      "Tickets are non-refundable, but you can resell your ticket through our official resale partner. Please note that tickets sold through unauthorized resellers may be invalidated.",
  },
  {
    question: "What items are prohibited at the venues?",
    answer:
      "Prohibited items typically include professional cameras, recording equipment, outside food and drinks, and weapons of any kind. Small personal cameras are usually permitted.",
  },
  {
    question: "Will there be merchandise available?",
    answer:
      "Yes, official CA$H STRAPPED merchandise will be available for purchase at all tour locations. We accept cash and card payments.",
  },
  {
    question: "How can I participate in the competition?",
    answer:
      "To participate in the CA$H STRAPPED competition, you need to submit your application through our website. Visit the 'Upload' section to submit your performance video.",
  },
]

export default function TourPage() {
  const [selectedLocation, setSelectedLocation] = useState<string | null>("leicester")
  const { playSound } = useSoundContext()

  // Get the featured location (Leicester)
  const featuredLocation = TOUR_LOCATIONS.find((loc) => loc.featured)

  const handleSelectLocation = (locationId: string) => {
    playSound("click")
    setSelectedLocation(locationId)
  }

  return (
    <div className="relative">
      {/* Animated Background */}
      <AnimatedBackground />

      {/* Hero Section */}
      <section className="relative py-16 md:py-24 overflow-hidden">
        {/* Background elements */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-black via-black/90 to-black/80"></div>

          {/* Decorative elements */}
          <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-gold/5 blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-gold/5 blur-3xl"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            className="text-center max-w-4xl mx-auto"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center bg-gold/10 px-4 py-2 rounded-full text-gold mb-6">
              <Star className="w-4 h-4 mr-2" />
              <span className="text-sm font-medium">UK NATIONAL TOUR 2025</span>
            </div>

            <h1 className="title-font text-5xl md:text-6xl lg:text-7xl mb-6 gold-text-gradient">
              THE ULTIMATE TALENT ROADSHOW
            </h1>

            <p className="body-font text-lg md:text-xl text-gold/80 mb-8 max-w-3xl mx-auto">
              Experience the UK's biggest talent competition live as we tour major cities across the nation. Don't miss
              your chance to witness the next generation of stars.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-6 px-8"
                onClick={() => playSound("click")}
              >
                <Ticket className="w-5 h-5 mr-2" />
                Get Tickets
              </Button>

              <Button
                variant="outline"
                className="border-gold/30 text-gold hover:bg-gold/10 py-6 px-8"
                onClick={() => playSound("click")}
              >
                <Calendar className="w-5 h-5 mr-2" />
                View Schedule
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured City Section */}
      {featuredLocation && (
        <section className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between mb-8">
              <h2 className="title-font text-3xl md:text-4xl text-gold">Featured Stop</h2>
              <Link
                href="/tour/leicester"
                className="text-gold/80 hover:text-gold flex items-center"
                onClick={() => playSound("click")}
              >
                <span>View Details</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
            </div>

            <CityHighlight
              city={featuredLocation.city}
              venue={featuredLocation.venue}
              date={featuredLocation.date}
              time={featuredLocation.time}
              description="Leicester's Curve Theatre hosts our tour opening night! Experience the kickoff of CA$H STRAPPED with special guest performances, exclusive opening night content, and the first chance to see this season's contestants live on stage. This flagship event sets the tone for our nationwide tour."
              image="/placeholder.svg?height=600&width=1200"
              ticketsUrl={featuredLocation.ticketsUrl}
              locationId={featuredLocation.id}
              available={featuredLocation.available}
              soldOut={featuredLocation.soldOut}
            />
          </div>
        </section>
      )}

      {/* Interactive Map & Timeline Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h2 className="title-font text-3xl md:text-4xl text-gold text-center mb-12">Tour Schedule</h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Interactive Map */}
            <div>
              <h3 className="text-gold text-xl mb-4 flex items-center">
                <MapPin className="w-5 h-5 mr-2" />
                Tour Locations
              </h3>

              <InteractiveMap
                locations={TOUR_LOCATIONS}
                selectedLocation={selectedLocation}
                onSelectLocation={handleSelectLocation}
              />
            </div>

            {/* Timeline */}
            <div>
              <h3 className="text-gold text-xl mb-4 flex items-center">
                <Calendar className="w-5 h-5 mr-2" />
                Event Schedule
              </h3>

              <TourTimeline
                locations={TOUR_LOCATIONS}
                selectedLocation={selectedLocation}
                onSelectLocation={handleSelectLocation}
              />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h2 className="title-font text-3xl md:text-4xl text-gold text-center mb-12">Frequently Asked Questions</h2>

          <TourFaq faqs={FAQS} className="max-w-3xl mx-auto" />
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <TourNewsletter className="max-w-3xl mx-auto" />
        </div>
      </section>
    </div>
  )
}
