import { Loader2 } from "lucide-react"

export default function LoginLoading() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="flex flex-col items-center">
        <Loader2 className="h-12 w-12 text-gold animate-spin mb-4" />
        <h2 className="text-gold text-xl">Loading...</h2>
      </div>
    </div>
  )
}
