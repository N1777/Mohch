import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"

export default function LoginNotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="text-center max-w-md">
        <div className="w-20 h-20 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-6">
          <AlertCircle className="w-10 h-10 text-gold" />
        </div>

        <h1 className="title-font text-4xl text-gold mb-4">Page Not Found</h1>

        <p className="text-white/70 mb-8">
          The login page you're looking for doesn't exist. Please return to the main login page.
        </p>

        <Link href="/login">
          <Button className="bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-3 px-6">
            Go to Login
          </Button>
        </Link>
      </div>
    </div>
  )
}
