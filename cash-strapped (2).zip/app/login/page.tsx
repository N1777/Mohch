"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { LoginForm } from "@/components/login/login-form"
import { ForgotPasswordForm } from "@/components/login/forgot-password-form"
import { AnimatedBackground } from "@/components/ui/animated-background"
import { useSoundContext } from "@/components/sound-provider"

export default function LoginPage() {
  const [view, setView] = useState<"login" | "forgot-password">("login")
  const router = useRouter()
  const { playSound } = useSoundContext()

  const handleViewChange = (newView: "login" | "forgot-password") => {
    playSound("click")
    setView(newView)
  }

  const handleLoginSuccess = () => {
    playSound("applause")
    // In a real app, this would handle authentication state
    router.push("/")
  }

  const handleForgotPasswordSuccess = () => {
    playSound("click")
    // Show success message and return to login
    setView("login")
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Animated Background */}
      <AnimatedBackground />

      <div className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-md">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden"
          >
            {/* Logo/Branding Header */}
            <div className="text-center p-6 border-b border-gold/10">
              <Link href="/" className="inline-block" onClick={() => playSound("click")}>
                <h1 className="logo-text text-3xl gold-text-gradient">CA$H STRAPPED</h1>
              </Link>
              <p className="text-gold/70 mt-2">
                {view === "login" ? "Sign in to your account" : "Reset your password"}
              </p>
            </div>

            {/* Form Container */}
            <div className="p-6">
              {view === "login" ? (
                <LoginForm
                  onForgotPassword={() => handleViewChange("forgot-password")}
                  onSuccess={handleLoginSuccess}
                />
              ) : (
                <ForgotPasswordForm
                  onBackToLogin={() => handleViewChange("login")}
                  onSuccess={handleForgotPasswordSuccess}
                />
              )}
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-gold/10 text-center">
              <p className="text-white/70">
                {view === "login" ? "Don't have an account?" : "Remember your password?"}
                {view === "login" ? (
                  <Link
                    href="/register"
                    className="text-gold hover:text-gold/80 ml-2"
                    onClick={() => playSound("click")}
                  >
                    Sign up
                  </Link>
                ) : (
                  <button className="text-gold hover:text-gold/80 ml-2" onClick={() => handleViewChange("login")}>
                    Sign in
                  </button>
                )}
              </p>
            </div>
          </motion.div>

          {/* Security Notice */}
          <p className="text-white/50 text-xs text-center mt-4">
            Secure login with 256-bit encryption. We never store your password in plain text.
          </p>
        </div>
      </div>
    </div>
  )
}
