import type React from "react"
import { Inter, Montserrat } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import "./globals.css"
import Header from "@/components/header"
import SoundProvider from "@/components/sound-provider"

// Add the font imports
const inter = Inter({ subsets: ["latin"] })
const montserrat = Montserrat({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-montserrat",
})

// Add the local fonts for Bebas Neue and Cinzel
const bebasNeue = {
  variable: "--font-bebas-neue",
  style: {
    fontFamily: "'Bebas Neue', sans-serif",
    fontDisplay: "swap",
  },
}

const cinzel = {
  variable: "--font-cinzel",
  style: {
    fontFamily: "'Cinzel', serif",
    fontDisplay: "swap",
  },
}

// Update the metadata
export const metadata = {
  title: "CA$H STRAPPED | UK's Ultimate Talent Roadshow",
  description: "The Ultimate UK's Talent Roadshow featuring Rap Battles and DJ Competitions",
    generator: 'v0.dev'
}

// Update the RootLayout component to include the font variables
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Add the font preload links */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Cinzel:wght@400;700;900&display=swap"
          rel="stylesheet"
        />

        {/* Preload critical images */}
        <link rel="preload" as="image" href="/images/leicester-background.png" />
        <link rel="preload" as="image" href="/images/premium-gold-trophy-cash.jpg" />
        <link rel="preload" as="image" href="/images/fallbacks/default-fallback.png" />
      </head>
      <body
        className={`${inter.className} ${montserrat.variable} ${bebasNeue.variable} ${cinzel.variable} bg-black min-h-screen`}
      >
        <ThemeProvider attribute="class" defaultTheme="dark">
          <SoundProvider>
            <div className="flex flex-col min-h-screen">
              <Header />
              <main className="flex-1">{children}</main>
              <footer className="border-t border-gold/20 py-6 text-center text-gold/60">
                <div className="container mx-auto">
                  <p>© {new Date().getFullYear()} CA$H STRAPPED. All rights reserved.</p>
                </div>
              </footer>
            </div>
            <Toaster />
          </SoundProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
