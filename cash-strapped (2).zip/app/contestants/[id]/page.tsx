"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { useSoundContext } from "@/components/sound-provider"
import { ThumbsUp, Award, Share2, ChevronLeft } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/components/ui/use-toast"
import { useParams, useRouter } from "next/navigation"
import { OptimizedImage } from "@/components/ui/optimized-image"

// Mock data for contestants
const CONTESTANTS = [
  {
    id: 1,
    name: "Lyrical Beast",
    category: "Rap Battle",
    city: "Leicester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1243,
    videoUrl: "/videos/contestant1.mp4",
    description:
      "Rising star from Leicester with hard-hitting bars and unique flow. Known for clever wordplay and stage presence that captivates the audience.",
    comments: [
      { id: 1, user: "Fan123", text: "Absolutely fire! Best performance I've seen 🔥", time: "2 hours ago" },
      { id: 2, user: "MusicLover", text: "The wordplay is next level", time: "5 hours ago" },
      { id: 3, user: "RapFan", text: "Deserves to win the whole competition!", time: "1 day ago" },
    ],
  },
  {
    id: 2,
    name: "DJ Spinmaster",
    category: "DJ Competition",
    city: "London",
    image: "/placeholder.svg?height=400&width=600",
    votes: 982,
    videoUrl: "/videos/contestant2.mp4",
    description:
      "London's hottest DJ bringing unique mixes and crowd-moving beats. Known for seamless transitions and reading the crowd like no other.",
    comments: [
      { id: 1, user: "ClubGoer", text: "Those transitions are so smooth!", time: "3 hours ago" },
      { id: 2, user: "BeatLover", text: "The way you mixed those tracks was genius", time: "1 day ago" },
    ],
  },
  {
    id: 3,
    name: "Flow Queen",
    category: "Rap Battle",
    city: "Manchester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1567,
    videoUrl: "/videos/contestant3.mp4",
    description:
      "Manchester's finest female MC with lyrics that tell stories and flows that break boundaries. Her authentic style has gained her a loyal following.",
    comments: [
      { id: 1, user: "HipHopHead", text: "Your flow is unmatched! Pure talent", time: "6 hours ago" },
      { id: 2, user: "MCFan", text: "The queen of the mic for real", time: "2 days ago" },
      { id: 3, user: "MusicCritic", text: "Bringing something fresh to the scene", time: "3 days ago" },
    ],
  },
  {
    id: 4,
    name: "Rhythm Crew",
    category: "Dance Crew",
    city: "Birmingham",
    image: "/placeholder.svg?height=400&width=600",
    votes: 2103,
    videoUrl: "/videos/contestant4.mp4",
    description:
      "Birmingham's elite dance crew combining street styles with contemporary moves. Their synchronized performances leave audiences speechless.",
    comments: [
      { id: 1, user: "DanceFan", text: "The synchronization is incredible!", time: "1 hour ago" },
      { id: 2, user: "MovesMaster", text: "Best crew in the competition hands down", time: "1 day ago" },
    ],
  },
  {
    id: 5,
    name: "Beat Maker",
    category: "Producer",
    city: "Bristol",
    image: "/placeholder.svg?height=400&width=600",
    votes: 876,
    videoUrl: "/videos/contestant5.mp4",
    description:
      "Bristol-based producer creating innovative beats that blend genres. His unique sound has caught the attention of major artists.",
    comments: [
      { id: 1, user: "MusicProducer", text: "Those samples are so creative", time: "4 hours ago" },
      { id: 2, user: "BeatHead", text: "The way you flip those samples is art", time: "2 days ago" },
    ],
  },
  {
    id: 6,
    name: "Verse Master",
    category: "Rap Battle",
    city: "Leeds",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1432,
    videoUrl: "/videos/contestant6.mp4",
    description:
      "Leeds' lyrical genius with a pen game that's unmatched. Known for complex rhyme schemes and thought-provoking content.",
    comments: [
      { id: 1, user: "WordSmith", text: "Your rhyme schemes are next level", time: "5 hours ago" },
      { id: 2, user: "LyricLover", text: "The wordplay is insane!", time: "1 day ago" },
    ],
  },
  {
    id: 7,
    name: "DJ Scratch",
    category: "DJ Competition",
    city: "Sheffield",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1089,
    videoUrl: "/videos/contestant7.mp4",
    description:
      "Sheffield's scratch master bringing old school techniques with modern flair. His technical skills behind the decks are unrivaled.",
    comments: [
      { id: 1, user: "VinylHead", text: "Those scratch techniques are incredible", time: "7 hours ago" },
      { id: 2, user: "DJFan", text: "Taking it back to the roots with those skills!", time: "3 days ago" },
    ],
  },
  {
    id: 8,
    name: "Street Moves",
    category: "Dance Crew",
    city: "Nottingham",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1765,
    videoUrl: "/videos/contestant8.mp4",
    description:
      "Nottingham's premier street dance crew bringing raw energy and innovative choreography. Their performances tell stories through movement.",
    comments: [
      { id: 1, user: "StreetDancer", text: "The choreography is so original", time: "2 hours ago" },
      { id: 2, user: "MovesMaster", text: "You guys deserve to win it all!", time: "2 days ago" },
    ],
  },
]

export default function ContestantDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { playSound } = useSoundContext()
  const { toast } = useToast()
  const [contestant, setContestant] = useState<any>(null)
  const [comment, setComment] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Find contestant by ID
    const id = Number(params.id)
    const found = CONTESTANTS.find((c) => c.id === id)

    if (found) {
      setContestant(found)
    } else {
      // Redirect to contestants page if not found
      router.push("/contestants")
    }

    setIsLoading(false)
  }, [params.id, router])

  const handleVote = () => {
    playSound("applause")
    setContestant((prev) => ({
      ...prev,
      votes: prev.votes + 1,
    }))

    toast({
      title: "Vote Recorded!",
      description: `You voted for ${contestant.name}`,
    })
  }

  const handleShare = () => {
    playSound("click")
    // In a real app, this would use the Web Share API
    navigator.clipboard.writeText(window.location.href)

    toast({
      title: "Link Copied!",
      description: "Share this contestant with your friends",
    })
  }

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault()

    if (!comment.trim()) return

    playSound("click")

    // Add new comment
    const newComment = {
      id: contestant.comments.length + 1,
      user: "You",
      text: comment,
      time: "Just now",
    }

    setContestant((prev) => ({
      ...prev,
      comments: [newComment, ...prev.comments],
    }))

    setComment("")

    toast({
      title: "Comment Added!",
      description: "Your comment has been posted",
    })
  }

  if (isLoading) {
    return (
      <div className="py-16 md:py-24 container mx-auto px-4 text-center">
        <p className="text-gold text-xl">Loading contestant...</p>
      </div>
    )
  }

  if (!contestant) {
    return (
      <div className="py-16 md:py-24 container mx-auto px-4 text-center">
        <p className="text-gold text-xl">Contestant not found</p>
        <Link href="/contestants">
          <Button className="gold-button mt-4">Back to Contestants</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="py-16 md:py-24 container mx-auto px-4">
      <Link href="/contestants" className="inline-flex items-center text-gold/80 hover:text-gold mb-8">
        <ChevronLeft className="h-4 w-4 mr-1" />
        Back to All Contestants
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-black/70 rounded-lg overflow-hidden">
            <div className="relative aspect-video">
              <OptimizedImage
                src={contestant.image}
                alt={contestant.name}
                fill
                className="object-cover"
                type="profile"
                fallbackCategory={contestant.category}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Button className="gold-button text-lg py-6 px-8" onClick={() => playSound("click")}>
                  Play Video
                </Button>
              </div>
            </div>

            <div className="p-6">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                <div>
                  <span className="text-sm text-gold/80 accent-font">{contestant.category}</span>
                  <h1 className="title-font text-gold text-3xl md:text-4xl">{contestant.name}</h1>
                  <p className="text-white/70">{contestant.city}</p>
                </div>

                <div className="flex items-center gap-2">
                  <Button className="vote-button bg-gold hover:bg-gold/90 text-black" onClick={handleVote}>
                    <ThumbsUp className="h-4 w-4 mr-2" />
                    Vote ({contestant.votes.toLocaleString()})
                  </Button>

                  <Button variant="outline" className="gold-outline-button" onClick={handleShare}>
                    <Share2 className="h-4 w-4 mr-2" />
                    Share
                  </Button>
                </div>
              </div>

              <p className="text-white/90 mb-6">{contestant.description}</p>

              <div className="border-t border-gold/20 pt-6">
                <h2 className="title-font text-gold text-xl mb-4">Comments</h2>

                <form onSubmit={handleComment} className="mb-6">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Add a comment..."
                      className="flex-1 bg-black/50 border border-gold/30 rounded-md px-4 py-2 text-white focus:outline-none focus:border-gold"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    />
                    <Button type="submit" className="gold-button">
                      Post
                    </Button>
                  </div>
                </form>

                <div className="space-y-4">
                  {contestant.comments.map((comment: any) => (
                    <div key={comment.id} className="bg-black/30 border border-gold/10 rounded-md p-4">
                      <div className="flex justify-between mb-2">
                        <span className="font-bold text-gold/90">{comment.user}</span>
                        <span className="text-white/50 text-sm">{comment.time}</span>
                      </div>
                      <p className="text-white/80">{comment.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="bg-black/70 rounded-lg p-6 mb-6">
            <h2 className="title-font text-gold text-xl mb-4">About {contestant.name}</h2>

            <div className="space-y-4">
              <div>
                <h3 className="text-gold/80 font-bold mb-1">Category</h3>
                <p className="text-white/90">{contestant.category}</p>
              </div>

              <div>
                <h3 className="text-gold/80 font-bold mb-1">Location</h3>
                <p className="text-white/90">{contestant.city}</p>
              </div>

              <div>
                <h3 className="text-gold/80 font-bold mb-1">Votes</h3>
                <p className="text-white/90">{contestant.votes.toLocaleString()}</p>
              </div>

              {contestant.votes > 1500 && (
                <div className="flex items-center text-gold bg-gold/10 p-3 rounded-md">
                  <Award className="h-5 w-5 mr-2" />
                  <span>Top Performer</span>
                </div>
              )}
            </div>
          </div>

          <div className="bg-black/70 rounded-lg p-6">
            <h2 className="title-font text-gold text-xl mb-4">Similar Contestants</h2>

            <div className="space-y-4">
              {CONTESTANTS.filter((c) => c.category === contestant.category && c.id !== contestant.id)
                .slice(0, 3)
                .map((similar) => (
                  <Link href={`/contestants/${similar.id}`} key={similar.id}>
                    <div className="flex items-center gap-3 p-2 hover:bg-gold/5 rounded-md transition-colors">
                      <div className="relative w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                        <OptimizedImage
                          src={similar.image}
                          alt={similar.name}
                          fill
                          className="object-cover"
                          type="thumbnail"
                          fallbackCategory={similar.category}
                        />
                      </div>
                      <div>
                        <h3 className="text-gold font-bold">{similar.name}</h3>
                        <p className="text-white/70 text-sm">{similar.city}</p>
                      </div>
                    </div>
                  </Link>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
