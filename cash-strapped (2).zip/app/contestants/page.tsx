"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { useSoundContext } from "@/components/sound-provider"
import { ThumbsUp, Award, Search } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { OptimizedImage } from "@/components/ui/optimized-image"

// Mock data for contestants
const ALL_CONTESTANTS = [
  {
    id: 1,
    name: "Lyrical Beast",
    category: "Rap Battle",
    city: "Leicester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1243,
    videoUrl: "/videos/contestant1.mp4",
  },
  {
    id: 2,
    name: "DJ Spinmaster",
    category: "DJ Competition",
    city: "London",
    image: "/placeholder.svg?height=400&width=600",
    votes: 982,
    videoUrl: "/videos/contestant2.mp4",
  },
  {
    id: 3,
    name: "Flow Queen",
    category: "Rap Battle",
    city: "Manchester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1567,
    videoUrl: "/videos/contestant3.mp4",
  },
  {
    id: 4,
    name: "Rhythm Crew",
    category: "Dance Crew",
    city: "Birmingham",
    image: "/placeholder.svg?height=400&width=600",
    votes: 2103,
    videoUrl: "/videos/contestant4.mp4",
  },
  {
    id: 5,
    name: "Beat Maker",
    category: "Producer",
    city: "Bristol",
    image: "/placeholder.svg?height=400&width=600",
    votes: 876,
    videoUrl: "/videos/contestant5.mp4",
  },
  {
    id: 6,
    name: "Verse Master",
    category: "Rap Battle",
    city: "Leeds",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1432,
    videoUrl: "/videos/contestant6.mp4",
  },
  {
    id: 7,
    name: "DJ Scratch",
    category: "DJ Competition",
    city: "Sheffield",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1089,
    videoUrl: "/videos/contestant7.mp4",
  },
  {
    id: 8,
    name: "Street Moves",
    category: "Dance Crew",
    city: "Nottingham",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1765,
    videoUrl: "/videos/contestant8.mp4",
  },
]

export default function ContestantsPage() {
  const [contestants, setContestants] = useState(ALL_CONTESTANTS)
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [cityFilter, setCityFilter] = useState("all")
  const { playSound } = useSoundContext()

  const handleVote = (id: number) => {
    playSound("applause")
    setContestants((prev) =>
      prev.map((contestant) => (contestant.id === id ? { ...contestant, votes: contestant.votes + 1 } : contestant)),
    )
  }

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
  }

  const filteredContestants = ALL_CONTESTANTS.filter((contestant) => {
    const matchesSearch = contestant.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || contestant.category === categoryFilter
    const matchesCity = cityFilter === "all" || contestant.city === cityFilter

    return matchesSearch && matchesCategory && matchesCity
  })

  return (
    <div className="py-16 md:py-24 container mx-auto px-4">
      <div className="text-center mb-16">
        <h1 className="title-font text-4xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient">CONTESTANTS</h1>
        <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto">
          Browse all contestants, watch their performances, and vote for your favorites!
        </p>
      </div>

      {/* Search and Filter */}
      <div className="mb-12 bg-black/50 border border-gold/30 p-6 rounded-lg">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
            <Input
              type="text"
              placeholder="Search contestants..."
              className="pl-10 bg-black/50 border-gold/30 focus:border-gold"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="bg-black/50 border-gold/30 focus:border-gold">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent className="bg-black border border-gold/30">
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="Rap Battle">Rap Battle</SelectItem>
              <SelectItem value="DJ Competition">DJ Competition</SelectItem>
              <SelectItem value="Dance Crew">Dance Crew</SelectItem>
              <SelectItem value="Producer">Producer</SelectItem>
            </SelectContent>
          </Select>

          <Select value={cityFilter} onValueChange={setCityFilter}>
            <SelectTrigger className="bg-black/50 border-gold/30 focus:border-gold">
              <SelectValue placeholder="Filter by city" />
            </SelectTrigger>
            <SelectContent className="bg-black border border-gold/30">
              <SelectItem value="all">All Cities</SelectItem>
              <SelectItem value="Leicester">Leicester</SelectItem>
              <SelectItem value="London">London</SelectItem>
              <SelectItem value="Manchester">Manchester</SelectItem>
              <SelectItem value="Birmingham">Birmingham</SelectItem>
              <SelectItem value="Bristol">Bristol</SelectItem>
              <SelectItem value="Leeds">Leeds</SelectItem>
              <SelectItem value="Sheffield">Sheffield</SelectItem>
              <SelectItem value="Nottingham">Nottingham</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredContestants.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredContestants.map((contestant) => (
            <div key={contestant.id} className="video-card bg-black/70 rounded-lg overflow-hidden">
              <div className="relative aspect-video">
                <OptimizedImage
                  src={contestant.image}
                  alt={contestant.name}
                  fill
                  className="object-cover"
                  type="card"
                  fallbackCategory={contestant.category}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-4">
                  <div>
                    <span className="text-xs text-gold/80 accent-font">{contestant.category}</span>
                    <h3 className="title-font text-gold text-xl">{contestant.name}</h3>
                    <p className="text-white/70 text-sm">{contestant.city}</p>
                  </div>
                </div>
              </div>

              <div className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <ThumbsUp className="text-gold h-4 w-4 mr-2" />
                    <span className="text-white/90">{contestant.votes.toLocaleString()} votes</span>
                  </div>

                  {contestant.votes > 1500 && (
                    <div className="flex items-center text-gold">
                      <Award className="h-4 w-4 mr-1" />
                      <span className="text-xs">Top Performer</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    className="vote-button flex-1 bg-gold hover:bg-gold/90 text-black"
                    onClick={() => handleVote(contestant.id)}
                  >
                    Vote Now
                  </Button>
                  <Link href={`/contestants/${contestant.id}`} className="flex-1">
                    <Button variant="outline" className="gold-outline-button w-full">
                      Watch
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-gold/80 text-xl mb-4">No contestants found matching your filters.</p>
          <Button
            className="gold-outline-button"
            onClick={() => {
              setSearchTerm("")
              setCategoryFilter("all")
              setCityFilter("all")
            }}
          >
            Reset Filters
          </Button>
        </div>
      )}

      <div className="mt-16 text-center">
        <Link href="/upload">
          <Button className="gold-button text-lg py-6 px-8">Submit Your Performance</Button>
        </Link>
      </div>
    </div>
  )
}
