"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useSoundContext } from "@/components/sound-provider"
import { useToast } from "@/components/ui/use-toast"
import { Upload, X, Check, Loader2, Camera } from "lucide-react"
import Image from "next/image"

export default function UploadPage() {
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [profileImage, setProfileImage] = useState<File | null>(null)
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [category, setCategory] = useState("")
  const [formData, setFormData] = useState({
    name: "",
    city: "",
    email: "",
    phone: "",
    socialMedia: "",
    motivation: "",
  })

  const videoInputRef = useRef<HTMLInputElement>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const { playSound } = useSoundContext()
  const { toast } = useToast()

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0]
      handleVideoFile(droppedFile)
    }
  }

  const handleVideoFile = (selectedFile: File) => {
    // Check if it's a video file
    if (!selectedFile.type.startsWith("video/")) {
      toast({
        title: "Invalid file type",
        description: "Please upload a video file.",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 100MB)
    if (selectedFile.size > 100 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Maximum file size is 100MB.",
        variant: "destructive",
      })
      return
    }

    setVideoFile(selectedFile)
    playSound("click")
  }

  const handleProfileImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0]

      // Check if it's an image file
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file.",
          variant: "destructive",
        })
        return
      }

      setProfileImage(file)

      // Create preview
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfileImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)

      playSound("click")
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!videoFile) {
      toast({
        title: "Video required",
        description: "Please upload your performance video.",
        variant: "destructive",
      })
      return
    }

    if (!category) {
      toast({
        title: "Category required",
        description: "Please select your performance category.",
        variant: "destructive",
      })
      return
    }

    setUploading(true)
    setUploadProgress(0)

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setUploading(false)

          // Show success message
          toast({
            title: "Submission successful!",
            description: "Your profile and video have been uploaded. Our team will review your submission.",
            variant: "default",
          })

          playSound("applause")

          // Reset form
          setVideoFile(null)
          setProfileImage(null)
          setProfileImagePreview(null)
          setCategory("")
          setFormData({
            name: "",
            city: "",
            email: "",
            phone: "",
            socialMedia: "",
            motivation: "",
          })
          setUploadProgress(0)

          return 0
        }
        return prev + 2
      })
    }, 100)
  }

  return (
    <div className="py-16 md:py-24 container mx-auto px-4">
      <div className="text-center mb-12">
        <h1 className="title-font text-4xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient">ARTIST SUBMISSION</h1>
        <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto">
          Show us your talent and join the UK's biggest talent roadshow! Upload your performance and tell us your story.
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <div className="bg-black/70 border border-gold/30 rounded-lg p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Profile Section */}
            <div className="space-y-6">
              <h2 className="title-font text-2xl text-gold border-b border-gold/30 pb-2">Your Profile</h2>

              <div className="flex flex-col md:flex-row gap-8 items-start">
                {/* Profile Image Upload */}
                <div className="w-full md:w-1/3">
                  <div className="flex flex-col items-center">
                    <div
                      className="w-40 h-40 rounded-full border-2 border-dashed border-gold/50 flex items-center justify-center overflow-hidden relative cursor-pointer"
                      onClick={() => imageInputRef.current?.click()}
                    >
                      {profileImagePreview ? (
                        <Image
                          src={profileImagePreview || "/placeholder.svg"}
                          alt="Profile Preview"
                          fill
                          className="object-cover"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-gold/70">
                          <Camera size={32} className="mb-2" />
                          <span className="text-sm text-center px-2">Add Profile Photo</span>
                        </div>
                      )}
                    </div>
                    <input
                      type="file"
                      ref={imageInputRef}
                      className="hidden"
                      accept="image/*"
                      onChange={handleProfileImage}
                    />
                    <p className="text-white/60 text-xs mt-2">Click to upload (Max 5MB)</p>
                  </div>
                </div>

                {/* Personal Details */}
                <div className="w-full md:w-2/3 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-gold/80 text-sm mb-1">
                        Full Name *
                      </label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="bg-black/50 border-gold/30 focus:border-gold"
                      />
                    </div>
                    <div>
                      <label htmlFor="city" className="block text-gold/80 text-sm mb-1">
                        City *
                      </label>
                      <Input
                        id="city"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                        className="bg-black/50 border-gold/30 focus:border-gold"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="category" className="block text-gold/80 text-sm mb-1">
                      Performance Category *
                    </label>
                    <Select value={category} onValueChange={setCategory} required>
                      <SelectTrigger className="bg-black/50 border-gold/30 focus:border-gold">
                        <SelectValue placeholder="Select your category" />
                      </SelectTrigger>
                      <SelectContent className="bg-black border border-gold/30">
                        <SelectItem value="rap">Rap Battle</SelectItem>
                        <SelectItem value="dj">DJ Competition</SelectItem>
                        <SelectItem value="dance">Dance Crew</SelectItem>
                        <SelectItem value="producer">Producer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="email" className="block text-gold/80 text-sm mb-1">
                        Email *
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="bg-black/50 border-gold/30 focus:border-gold"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-gold/80 text-sm mb-1">
                        Phone Number
                      </label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="bg-black/50 border-gold/30 focus:border-gold"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="socialMedia" className="block text-gold/80 text-sm mb-1">
                      Social Media Handles
                    </label>
                    <Input
                      id="socialMedia"
                      name="socialMedia"
                      value={formData.socialMedia}
                      onChange={handleInputChange}
                      placeholder="Instagram, TikTok, etc."
                      className="bg-black/50 border-gold/30 focus:border-gold"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Motivation Letter */}
            <div className="space-y-4">
              <h2 className="title-font text-2xl text-gold border-b border-gold/30 pb-2">Your Story</h2>

              <div>
                <label htmlFor="motivation" className="block text-gold/80 text-sm mb-1">
                  Motivation Letter *
                </label>
                <Textarea
                  id="motivation"
                  name="motivation"
                  value={formData.motivation}
                  onChange={handleInputChange}
                  required
                  placeholder="Tell us about yourself, your journey, and why you should be part of CA$H STRAPPED..."
                  className="bg-black/50 border-gold/30 focus:border-gold min-h-[150px]"
                />
              </div>
            </div>

            {/* Video Upload */}
            <div className="space-y-4">
              <h2 className="title-font text-2xl text-gold border-b border-gold/30 pb-2">Your Performance</h2>

              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${
                  videoFile ? "border-gold bg-gold/5" : "border-gold/30 hover:border-gold/50"
                }`}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
              >
                {!videoFile ? (
                  <div className="py-8">
                    <Upload className="h-12 w-12 mx-auto text-gold mb-4" />
                    <h3 className="title-font text-gold text-xl mb-2">Drag & Drop Your Performance Video</h3>
                    <p className="text-white/70 mb-6">Or click to browse your files (Max size: 100MB)</p>
                    <Button className="gold-button" onClick={() => videoInputRef.current?.click()}>
                      Select Video
                    </Button>
                    <input
                      type="file"
                      ref={videoInputRef}
                      className="hidden"
                      accept="video/*"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          handleVideoFile(e.target.files[0])
                        }
                      }}
                    />
                  </div>
                ) : (
                  <div className="py-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-gold/20 rounded flex items-center justify-center mr-4">
                          <Check className="h-6 w-6 text-gold" />
                        </div>
                        <div className="text-left">
                          <p className="text-white font-medium truncate max-w-xs">{videoFile.name}</p>
                          <p className="text-white/60 text-sm">{(videoFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-white/70 hover:text-white"
                        onClick={() => setVideoFile(null)}
                        disabled={uploading}
                      >
                        <X className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Submit Section */}
            <div className="pt-4 border-t border-gold/20">
              {uploading && (
                <div className="mb-6">
                  <p className="text-gold mb-2 text-center">Uploading your submission...</p>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gold transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              <div className="flex justify-end">
                <Button type="submit" className="gold-button text-lg py-6 px-8" disabled={uploading}>
                  {uploading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    "Submit Application"
                  )}
                </Button>
              </div>
            </div>
          </form>
        </div>

        <div className="mt-8 bg-black/50 border border-gold/30 p-6 rounded-lg">
          <h3 className="title-font text-gold text-xl mb-4">Submission Guidelines</h3>
          <ul className="text-white/80 space-y-2 list-disc pl-5">
            <li>Videos must be under 3 minutes in length</li>
            <li>Content must be original and performed by you</li>
            <li>Ensure good lighting and audio quality</li>
            <li>Submissions will be reviewed before being published</li>
            <li>Selected contestants will be contacted for the live shows</li>
            <li>By uploading, you agree to our terms and conditions</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
