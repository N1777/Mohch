"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { useSoundContext } from "./sound-provider"
import { ThumbsUp, Award } from "lucide-react"
import Link from "next/link"
import { OptimizedImage } from "./ui/optimized-image"

// Mock data for contestants
const CONTESTANTS = [
  {
    id: 1,
    name: "Lyrical Beast",
    category: "Rap Battle",
    city: "Leicester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1243,
    videoUrl: "/videos/contestant1.mp4",
  },
  {
    id: 2,
    name: "DJ Spinmaster",
    category: "DJ Competition",
    city: "London",
    image: "/placeholder.svg?height=400&width=600",
    votes: 982,
    videoUrl: "/videos/contestant2.mp4",
  },
  {
    id: 3,
    name: "Flow Queen",
    category: "Rap Battle",
    city: "Manchester",
    image: "/placeholder.svg?height=400&width=600",
    votes: 1567,
    videoUrl: "/videos/contestant3.mp4",
  },
  {
    id: 4,
    name: "Rhythm Crew",
    category: "Dance Crew",
    city: "Birmingham",
    image: "/placeholder.svg?height=400&width=600",
    votes: 2103,
    videoUrl: "/videos/contestant4.mp4",
  },
]

export default function FeaturedContestants() {
  const [contestants, setContestants] = useState(CONTESTANTS)
  const { playSound } = useSoundContext()

  const handleVote = (id: number) => {
    playSound("applause")
    setContestants((prev) =>
      prev.map((contestant) => (contestant.id === id ? { ...contestant, votes: contestant.votes + 1 } : contestant)),
    )
  }

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-black to-black/90">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="title-font text-4xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient">FEATURED CONTESTANTS</h2>
          <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto">
            Check out our top performers and vote for your favorites. Your votes determine who advances to the next
            round!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {contestants.map((contestant) => (
            <div key={contestant.id} className="video-card bg-black/70 rounded-lg overflow-hidden">
              <div className="relative aspect-video">
                <OptimizedImage
                  src={contestant.image}
                  alt={contestant.name}
                  fill
                  className="object-cover"
                  type="card"
                  fallbackCategory={contestant.category}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-4">
                  <div>
                    <span className="text-xs text-gold/80 accent-font">{contestant.category}</span>
                    <h3 className="title-font text-gold text-xl">{contestant.name}</h3>
                    <p className="text-white/70 text-sm">{contestant.city}</p>
                  </div>
                </div>
              </div>

              <div className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center">
                    <ThumbsUp className="text-gold h-4 w-4 mr-2" />
                    <span className="text-white/90">{contestant.votes.toLocaleString()} votes</span>
                  </div>

                  {contestant.votes > 1500 && (
                    <div className="flex items-center text-gold">
                      <Award className="h-4 w-4 mr-1" />
                      <span className="text-xs">Top Performer</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    className="vote-button flex-1 bg-gold hover:bg-gold/90 text-black"
                    onClick={() => handleVote(contestant.id)}
                  >
                    Vote Now
                  </Button>
                  <Link href={`/contestants/${contestant.id}`} className="flex-1">
                    <Button variant="outline" className="gold-outline-button w-full">
                      Watch
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link href="/contestants">
            <Button className="gold-button text-lg py-6 px-8">View All Contestants</Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
