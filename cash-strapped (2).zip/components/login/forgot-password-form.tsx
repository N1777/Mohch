"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Mail, ArrowLeft, AlertCircle, Loader2, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

interface ForgotPasswordFormProps {
  onBackToLogin: () => void
  onSuccess: () => void
}

export function ForgotPasswordForm({ onBackToLogin, onSuccess }: ForgotPasswordFormProps) {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [validationError, setValidationError] = useState<string | null>(null)

  // Email validation
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    const isValid = emailRegex.test(email)

    setValidationError(isValid ? null : "Please enter a valid email address")

    return isValid
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Reset states
    setError(null)
    setIsSuccess(false)

    // Validate email
    if (!validateEmail(email)) {
      return
    }

    // Simulate API call
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // For demo purposes, always succeed
      setIsSuccess(true)

      // Notify parent component
      setTimeout(() => {
        onSuccess()
      }, 2000)
    } catch (err) {
      setError("An error occurred. Please try again later.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Error message */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 flex items-start"
          >
            <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-red-400 text-sm">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success message */}
      <AnimatePresence>
        {isSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 flex items-start"
          >
            <CheckCircle className="w-5 h-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-green-400 text-sm">Password reset instructions have been sent to your email address.</p>
          </motion.div>
        )}
      </AnimatePresence>

      <p className="text-white/70">Enter your email address and we'll send you instructions to reset your password.</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email field */}
        <div className="space-y-2">
          <label htmlFor="reset-email" className="block text-sm font-medium text-gold/80">
            Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
            <Input
              id="reset-email"
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value)
                if (e.target.value) validateEmail(e.target.value)
              }}
              onBlur={() => validateEmail(email)}
              placeholder="your@email.com"
              className={cn(
                "pl-10 bg-black/50 border-gold/30 focus:border-gold",
                validationError && "border-red-500/50 focus:border-red-500",
              )}
              disabled={isLoading || isSuccess}
              required
            />
          </div>
          {validationError && <p className="text-red-400 text-xs mt-1">{validationError}</p>}
        </div>

        {/* Submit button */}
        <Button
          type="submit"
          className="w-full bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-5"
          disabled={isLoading || isSuccess}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending...
            </>
          ) : (
            "Send Reset Instructions"
          )}
        </Button>

        {/* Back to login */}
        <Button
          type="button"
          variant="ghost"
          className="w-full text-gold/70 hover:text-gold hover:bg-gold/5"
          onClick={onBackToLogin}
          disabled={isLoading}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to login
        </Button>
      </form>
    </div>
  )
}
