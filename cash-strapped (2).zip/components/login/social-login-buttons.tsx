"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"

interface SocialLoginButtonsProps {
  onSuccess: () => void
}

export function SocialLoginButtons({ onSuccess }: SocialLoginButtonsProps) {
  const [isLoading, setIsLoading] = useState<string | null>(null)

  const handleSocialLogin = async (provider: string) => {
    setIsLoading(provider)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // For demo purposes, always succeed
      onSuccess()
    } catch (error) {
      console.error(`Error logging in with ${provider}:`, error)
    } finally {
      setIsLoading(null)
    }
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
      {/* Google */}
      <Button
        type="button"
        variant="outline"
        className="bg-black/50 border-gold/30 hover:bg-gold/5 text-white/80 hover:text-white"
        onClick={() => handleSocialLogin("google")}
        disabled={isLoading !== null}
      >
        {isLoading === "google" ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24">
            <path
              fill="currentColor"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="currentColor"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="currentColor"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
            />
            <path
              fill="currentColor"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            />
          </svg>
        )}
        Google
      </Button>

      {/* Apple */}
      <Button
        type="button"
        variant="outline"
        className="bg-black/50 border-gold/30 hover:bg-gold/5 text-white/80 hover:text-white"
        onClick={() => handleSocialLogin("apple")}
        disabled={isLoading !== null}
      >
        {isLoading === "apple" ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24">
            <path
              fill="currentColor"
              d="M16.125 0.1875C14.2969 0.332031 12.1406 1.5 10.9688 3.02344C9.89062 4.40625 9.14062 6.32031 9.42188 8.14844C11.3906 8.17969 13.4062 6.96875 14.5312 5.42188C15.6094 3.92969 16.2656 2.04688 16.125 0.1875ZM16.1719 8.29688C13.3594 8.29688 12.25 10.0781 10.0781 10.0781C7.85938 10.0781 5.09375 7.71875 2.75 7.71875C0.40625 7.71875 0 12.0156 0 12.0156C0 17.9688 4.03125 23.5312 6.59375 23.5312C8.6875 23.5312 9.21875 22.0156 10.9062 22.0156C12.6406 22.0156 13.5469 23.5312 15.4062 23.5312C17.2656 23.5312 20.2188 19.7188 21.7969 16.7656C22.6406 15.1719 22.9844 14.3438 23 14.2969C22.9688 14.2812 19.0156 12.7344 19.0156 8.32812C19.0156 4.67188 22.125 3.02344 22.2188 2.96875C20.4219 0.375 17.5781 0.28125 16.1719 0.28125V8.29688Z"
            />
          </svg>
        )}
        Apple
      </Button>

      {/* Twitter/X */}
      <Button
        type="button"
        variant="outline"
        className="bg-black/50 border-gold/30 hover:bg-gold/5 text-white/80 hover:text-white"
        onClick={() => handleSocialLogin("twitter")}
        disabled={isLoading !== null}
      >
        {isLoading === "twitter" ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24">
            <path
              fill="currentColor"
              d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"
            />
          </svg>
        )}
        X
      </Button>
    </div>
  )
}
