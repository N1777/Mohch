"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Eye, EyeOff, Lock, Mail, AlertCircle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { SocialLoginButtons } from "./social-login-buttons"
import { cn } from "@/lib/utils"

interface LoginFormProps {
  onForgotPassword: () => void
  onSuccess: () => void
}

export function LoginForm({ onForgotPassword, onSuccess }: LoginFormProps) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [validationErrors, setValidationErrors] = useState<{
    email?: string
    password?: string
  }>({})

  // Email validation
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    const isValid = emailRegex.test(email)

    setValidationErrors((prev) => ({
      ...prev,
      email: isValid ? undefined : "Please enter a valid email address",
    }))

    return isValid
  }

  // Password validation
  const validatePassword = (password: string): boolean => {
    const isValid = password.length >= 6

    setValidationErrors((prev) => ({
      ...prev,
      password: isValid ? undefined : "Password must be at least 6 characters",
    }))

    return isValid
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Reset error state
    setError(null)

    // Validate inputs
    const isEmailValid = validateEmail(email)
    const isPasswordValid = validatePassword(password)

    if (!isEmailValid || !isPasswordValid) {
      return
    }

    // Simulate login process
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // For demo purposes, let's simulate a successful login
      // In a real app, this would verify credentials with a backend
      if (email === "demo@example.com" && password === "password") {
        onSuccess()
      } else {
        setError("Invalid email or password. Please try again.")
      }
    } catch (err) {
      setError("An error occurred. Please try again later.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Error message */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 flex items-start"
          >
            <AlertCircle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
            <p className="text-red-400 text-sm">{error}</p>
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email field */}
        <div className="space-y-2">
          <label htmlFor="email" className="block text-sm font-medium text-gold/80">
            Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value)
                if (e.target.value) validateEmail(e.target.value)
              }}
              onBlur={() => validateEmail(email)}
              placeholder="your@email.com"
              className={cn(
                "pl-10 bg-black/50 border-gold/30 focus:border-gold",
                validationErrors.email && "border-red-500/50 focus:border-red-500",
              )}
              disabled={isLoading}
              required
            />
          </div>
          {validationErrors.email && <p className="text-red-400 text-xs mt-1">{validationErrors.email}</p>}
        </div>

        {/* Password field */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label htmlFor="password" className="block text-sm font-medium text-gold/80">
              Password
            </label>
            <button type="button" onClick={onForgotPassword} className="text-gold/70 hover:text-gold text-xs">
              Forgot password?
            </button>
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value)
                if (e.target.value) validatePassword(e.target.value)
              }}
              onBlur={() => validatePassword(password)}
              placeholder="••••••••"
              className={cn(
                "pl-10 pr-10 bg-black/50 border-gold/30 focus:border-gold",
                validationErrors.password && "border-red-500/50 focus:border-red-500",
              )}
              disabled={isLoading}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gold/60 hover:text-gold"
              tabIndex={-1}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {validationErrors.password && <p className="text-red-400 text-xs mt-1">{validationErrors.password}</p>}
        </div>

        {/* Remember me checkbox */}
        <div className="flex items-center space-x-2">
          <Checkbox
            id="remember"
            checked={rememberMe}
            onCheckedChange={(checked) => setRememberMe(checked as boolean)}
            className="border-gold/50 data-[state=checked]:bg-gold data-[state=checked]:text-black"
          />
          <label htmlFor="remember" className="text-sm text-white/70 leading-none cursor-pointer">
            Remember me for 30 days
          </label>
        </div>

        {/* Submit button */}
        <Button
          type="submit"
          className="w-full bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-5"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Signing in...
            </>
          ) : (
            "Sign in"
          )}
        </Button>
      </form>

      {/* Divider */}
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gold/10"></div>
        </div>
        <div className="relative flex justify-center text-xs">
          <span className="px-2 bg-black/40 text-white/50">Or continue with</span>
        </div>
      </div>

      {/* Social login buttons */}
      <SocialLoginButtons onSuccess={onSuccess} />

      {/* Demo credentials helper */}
      <div className="bg-gold/5 border border-gold/10 rounded-lg p-3">
        <p className="text-white/70 text-xs text-center">
          <span className="text-gold/80">Demo credentials:</span> demo@example.com / password
        </p>
      </div>
    </div>
  )
}
