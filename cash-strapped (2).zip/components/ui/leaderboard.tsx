"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Trophy, Medal, Award, ChevronDown, ChevronUp } from "lucide-react"
import { OptimizedImage } from "./optimized-image"
import { cn } from "@/lib/utils"

interface LeaderboardProps {
  contestants: {
    id: number
    name: string
    category: string
    city: string
    image: string
    votes: number
  }[]
  title?: string
  limit?: number
  className?: string
}

export function Leaderboard({ contestants, title = "Top Contestants", limit = 5, className = "" }: LeaderboardProps) {
  const [expanded, setExpanded] = useState(false)

  // Sort contestants by votes
  const sortedContestants = [...contestants].sort((a, b) => b.votes - a.votes)

  // Get top contestants based on limit or expanded state
  const displayedContestants = expanded ? sortedContestants : sortedContestants.slice(0, limit)

  return (
    <motion.div
      className={cn("bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden", className)}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="p-5">
        <h3 className="text-gold title-font text-xl mb-4">{title}</h3>

        <div className="space-y-3">
          {displayedContestants.map((contestant, index) => (
            <motion.div
              key={contestant.id}
              className={cn(
                "flex items-center gap-3 p-3 rounded-lg",
                index === 0
                  ? "bg-gold/10 border border-gold/30"
                  : index < 3
                    ? "bg-black/50 border border-gold/20"
                    : "bg-black/30",
              )}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              {/* Rank */}
              <div className="w-8 flex-shrink-0">
                {index === 0 ? (
                  <Trophy className="h-6 w-6 text-gold" />
                ) : index === 1 ? (
                  <Medal className="h-6 w-6 text-gold/80" />
                ) : index === 2 ? (
                  <Award className="h-6 w-6 text-gold/70" />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-black/50 flex items-center justify-center text-gold/60 text-sm">
                    {index + 1}
                  </div>
                )}
              </div>

              {/* Contestant Image */}
              <div className="relative w-10 h-10 rounded-full overflow-hidden flex-shrink-0 border border-gold/30">
                <OptimizedImage
                  src={contestant.image}
                  alt={contestant.name}
                  fill
                  className="object-cover"
                  type="thumbnail"
                  fallbackCategory={contestant.category}
                />
              </div>

              {/* Contestant Info */}
              <div className="flex-grow min-w-0">
                <h4 className="text-gold font-medium truncate">{contestant.name}</h4>
                <div className="flex items-center text-white/60 text-xs">
                  <span className="truncate">{contestant.category}</span>
                  <span className="mx-1">•</span>
                  <span className="truncate">{contestant.city}</span>
                </div>
              </div>

              {/* Vote Count */}
              <div className="text-right flex-shrink-0">
                <div className="text-gold font-medium">{contestant.votes.toLocaleString()}</div>
                <div className="text-white/60 text-xs">votes</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Show more/less button */}
        {contestants.length > limit && (
          <button
            className="w-full mt-4 py-2 flex items-center justify-center text-gold/70 hover:text-gold text-sm border-t border-gold/10"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? (
              <>
                Show Less <ChevronUp className="ml-1 w-4 h-4" />
              </>
            ) : (
              <>
                Show More <ChevronDown className="ml-1 w-4 h-4" />
              </>
            )}
          </button>
        )}
      </div>
    </motion.div>
  )
}
