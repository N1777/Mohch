"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Filter, X } from "lucide-react"
import { Input } from "./input"
import { cn } from "@/lib/utils"

interface FilterOption {
  value: string
  label: string
}

interface FilterBarProps {
  searchValue: string
  onSearchChange: (value: string) => void
  categories: FilterOption[]
  selectedCategory: string
  onCategoryChange: (value: string) => void
  cities: FilterOption[]
  selectedCity: string
  onCityChange: (value: string) => void
  sortOptions: FilterOption[]
  selectedSort: string
  onSortChange: (value: string) => void
}

export function FilterBar({
  searchValue,
  onSearchChange,
  categories,
  selectedCategory,
  onCategoryChange,
  cities,
  selectedCity,
  onCityChange,
  sortOptions,
  selectedSort,
  onSortChange,
}: FilterBarProps) {
  const [showFilters, setShowFilters] = useState(false)

  return (
    <div className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden transition-all">
      {/* Search Bar */}
      <div className="p-4 flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
          <Input
            type="text"
            placeholder="Search contestants..."
            className="pl-10 bg-black/50 border-gold/30 focus:border-gold rounded-lg"
            value={searchValue}
            onChange={(e) => onSearchChange(e.target.value)}
          />
          {searchValue && (
            <button
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gold/60 hover:text-gold"
              onClick={() => onSearchChange("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <button
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-lg border transition-colors",
            showFilters
              ? "bg-gold/10 border-gold/50 text-gold"
              : "border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
          )}
          onClick={() => setShowFilters(!showFilters)}
        >
          <Filter className="h-4 w-4" />
          <span className="hidden sm:inline">Filters</span>
          {(selectedCategory !== "all" || selectedCity !== "all" || selectedSort !== "popular") && (
            <span className="inline-flex items-center justify-center w-5 h-5 text-xs bg-gold text-black rounded-full">
              {(selectedCategory !== "all" ? 1 : 0) +
                (selectedCity !== "all" ? 1 : 0) +
                (selectedSort !== "popular" ? 1 : 0)}
            </span>
          )}
        </button>
      </div>

      {/* Expanded Filters */}
      {showFilters && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="px-4 pb-4 border-t border-gold/10"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
            {/* Categories */}
            <div>
              <label className="block text-gold/80 text-sm mb-2">Category</label>
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <button
                    key={category.value}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-sm transition-colors",
                      selectedCategory === category.value
                        ? "bg-gold text-black font-medium"
                        : "bg-black/50 border border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                    )}
                    onClick={() => onCategoryChange(category.value)}
                  >
                    {category.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Cities */}
            <div>
              <label className="block text-gold/80 text-sm mb-2">City</label>
              <div className="flex flex-wrap gap-2">
                {cities.map((city) => (
                  <button
                    key={city.value}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-sm transition-colors",
                      selectedCity === city.value
                        ? "bg-gold text-black font-medium"
                        : "bg-black/50 border border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                    )}
                    onClick={() => onCityChange(city.value)}
                  >
                    {city.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sort Options */}
            <div>
              <label className="block text-gold/80 text-sm mb-2">Sort By</label>
              <div className="flex flex-wrap gap-2">
                {sortOptions.map((option) => (
                  <button
                    key={option.value}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-sm transition-colors",
                      selectedSort === option.value
                        ? "bg-gold text-black font-medium"
                        : "bg-black/50 border border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                    )}
                    onClick={() => onSortChange(option.value)}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Reset Filters */}
          {(selectedCategory !== "all" || selectedCity !== "all" || selectedSort !== "popular") && (
            <div className="mt-4 flex justify-end">
              <button
                className="text-gold/70 hover:text-gold text-sm flex items-center gap-1"
                onClick={() => {
                  onCategoryChange("all")
                  onCityChange("all")
                  onSortChange("popular")
                }}
              >
                <X className="h-3 w-3" />
                Reset all filters
              </button>
            </div>
          )}
        </motion.div>
      )}
    </div>
  )
}
