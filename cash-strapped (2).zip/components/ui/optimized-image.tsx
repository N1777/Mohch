"use client"

import { useState } from "react"
import Image from "next/image"
import { DEFAULT_IMAGE_QUALITY, getFallbackImageUrl, getResponsiveSizes } from "@/utils/image-utils"

interface OptimizedImageProps {
  src: string
  alt: string
  fill?: boolean
  width?: number
  height?: number
  className?: string
  priority?: boolean
  quality?: number
  type?: "hero" | "card" | "profile" | "background" | "thumbnail"
  fallbackCategory?: string
  objectFit?: "cover" | "contain" | "fill" | "none" | "scale-down"
  objectPosition?: string
}

export function OptimizedImage({
  src,
  alt,
  fill = false,
  width,
  height,
  className = "",
  priority = false,
  quality = DEFAULT_IMAGE_QUALITY,
  type = "card",
  fallbackCategory,
  objectFit = "cover",
  objectPosition = "center",
}: OptimizedImageProps) {
  const [imgSrc, setImgSrc] = useState(src)
  const [isError, setIsError] = useState(false)

  // Handle image load error
  const handleError = () => {
    if (!isError) {
      setIsError(true)
      setImgSrc(getFallbackImageUrl(fallbackCategory))
    }
  }

  // Determine object fit and position classes
  const objectFitClass = `object-${objectFit}`
  const objectPositionClass = objectPosition === "center" ? "object-center" : `object-${objectPosition}`

  // Combine classes
  const imageClasses = `transition-opacity duration-300 ${objectFitClass} ${objectPositionClass} ${className}`

  // Get responsive sizes
  const sizes = getResponsiveSizes(type)

  // If using fill
  if (fill) {
    return (
      <Image
        src={imgSrc || "/placeholder.svg"}
        alt={alt}
        fill
        sizes={sizes}
        quality={quality}
        priority={priority}
        className={imageClasses}
        onError={handleError}
      />
    )
  }

  // If using explicit dimensions
  return (
    <Image
      src={imgSrc || "/placeholder.svg"}
      alt={alt}
      width={width || 800}
      height={height || 600}
      sizes={sizes}
      quality={quality}
      priority={priority}
      className={imageClasses}
      onError={handleError}
    />
  )
}
