"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Mail, Check, Loader2 } from "lucide-react"
import { Input } from "./input"
import { Button } from "./button"
import { cn } from "@/lib/utils"

interface TourNewsletterProps {
  className?: string
}

export function TourNewsletter({ className }: TourNewsletterProps) {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Reset states
    setError(null)
    setIsSuccess(false)

    // Validate email
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      setError("Please enter a valid email address")
      return
    }

    // Simulate form submission
    setIsSubmitting(true)

    setTimeout(() => {
      setIsSubmitting(false)
      setIsSuccess(true)
      setEmail("")
    }, 1500)
  }

  return (
    <motion.div
      className={cn("bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 overflow-hidden", className)}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="p-6 md:p-8">
        <div className="flex items-center justify-center w-16 h-16 rounded-full bg-gold/10 mx-auto mb-6">
          <Mail className="w-8 h-8 text-gold" />
        </div>

        <h3 className="title-font text-2xl md:text-3xl text-gold text-center mb-3">Stay Updated on Tour Dates</h3>

        <p className="text-white/70 text-center mb-6 max-w-md mx-auto">
          Subscribe to our newsletter to receive the latest updates on tour dates, ticket releases, and exclusive
          behind-the-scenes content.
        </p>

        <form onSubmit={handleSubmit} className="max-w-md mx-auto">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-black/50 border-gold/30 focus:border-gold w-full py-6 pl-10"
                disabled={isSubmitting || isSuccess}
              />
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-5 w-5" />
            </div>

            <Button
              type="submit"
              className={cn(
                "py-6 px-6 rounded-lg transition-all",
                isSuccess ? "bg-green-600 text-white" : "bg-gradient-to-r from-gold/90 to-gold text-black font-medium",
              )}
              disabled={isSubmitting || isSuccess}
            >
              {isSubmitting ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : isSuccess ? (
                <>
                  <Check className="w-5 h-5 mr-2" />
                  <span>Subscribed</span>
                </>
              ) : (
                "Subscribe"
              )}
            </Button>
          </div>

          {error && <p className="mt-2 text-red-400 text-sm">{error}</p>}

          {isSuccess && (
            <motion.p
              className="mt-2 text-green-400 text-sm"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              Thank you for subscribing! Check your email for confirmation.
            </motion.p>
          )}
        </form>
      </div>
    </motion.div>
  )
}
