"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Calendar, Clock, MapPin, Ticket, ArrowRight } from "lucide-react"
import { OptimizedImage } from "./optimized-image"
import { cn } from "@/lib/utils"
import Link from "next/link"

interface CityHighlightProps {
  city: string
  venue: string
  date: string
  time: string
  description: string
  image: string
  ticketsUrl: string
  locationId: string
  available: boolean
  soldOut?: boolean
  className?: string
}

export function CityHighlight({
  city,
  venue,
  date,
  time,
  description,
  image,
  ticketsUrl,
  locationId,
  available,
  soldOut = false,
  className,
}: CityHighlightProps) {
  const [isHovering, setIsHovering] = useState(false)

  return (
    <motion.div
      className={cn("group relative overflow-hidden rounded-xl border border-gold/30", className)}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <OptimizedImage
          src={image}
          alt={`${city} - ${venue}`}
          fill
          className={cn("object-cover transition-transform duration-10000", isHovering ? "scale-110" : "scale-100")}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 p-6 md:p-8">
        <div className="flex flex-col h-full justify-between gap-6">
          <div>
            <div className="inline-flex items-center bg-gold/20 px-3 py-1 rounded-full text-gold text-sm mb-4">
              <Calendar className="w-4 h-4 mr-2" />
              <span>{date}</span>
              <span className="mx-2">•</span>
              <Clock className="w-4 h-4 mr-2" />
              <span>{time}</span>
            </div>

            <h3 className="title-font text-3xl md:text-4xl text-gold mb-2">{city}</h3>
            <div className="flex items-center text-white/80 mb-4">
              <MapPin className="w-4 h-4 mr-2 text-gold/80" />
              <span>{venue}</span>
            </div>

            <p className="text-white/70 mb-6 max-w-lg">{description}</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <a
              href={ticketsUrl}
              className={cn(
                "py-3 px-6 rounded-lg flex items-center justify-center gap-2 transition-all",
                available && !soldOut
                  ? "bg-gradient-to-r from-gold/90 to-gold text-black font-medium"
                  : "bg-white/10 text-white/50 cursor-not-allowed",
              )}
              onClick={(e) => (!available || soldOut) && e.preventDefault()}
            >
              <Ticket className="w-5 h-5" />
              <span>{soldOut ? "Sold Out" : available ? "Buy Tickets" : "Coming Soon"}</span>
            </a>

            <Link
              href={`/tour/${locationId}`}
              className="py-3 px-6 rounded-lg border border-gold/30 text-gold hover:bg-gold/10 flex items-center justify-center gap-2 transition-all"
            >
              <span>Event Details</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
