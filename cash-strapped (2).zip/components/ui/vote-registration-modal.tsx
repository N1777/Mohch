"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Check, ArrowRight, Mail, User } from "lucide-react"
import { Input } from "./input"
import { Checkbox } from "./checkbox"
import { Button } from "./button"

interface VoteRegistrationModalProps {
  isOpen: boolean
  onClose: () => void
  onRegister: (data: RegistrationData) => void
}

export interface RegistrationData {
  name: string
  email: string
  receiveUpdates: boolean
}

export function VoteRegistrationModal({ isOpen, onClose, onRegister }: VoteRegistrationModalProps) {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState<RegistrationData>({
    name: "",
    email: "",
    receiveUpdates: true,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate submission
    setTimeout(() => {
      onRegister(formData)
      setIsSubmitting(false)
      onClose()
      // Reset for next time
      setStep(1)
    }, 1000)
  }

  const nextStep = () => {
    setStep(2)
  }

  const modalVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.3 } },
    exit: { opacity: 0, y: 50, transition: { duration: 0.2 } },
  }

  const overlayVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.3 } },
    exit: { opacity: 0, transition: { duration: 0.2 } },
  }

  if (!isOpen) return null

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            variants={overlayVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            className="bg-black/90 border border-gold/30 rounded-2xl w-full max-w-md overflow-hidden z-10"
            variants={modalVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            {/* Header */}
            <div className="relative p-6 border-b border-gold/20">
              <button
                className="absolute right-6 top-6 text-gold/60 hover:text-gold transition-colors"
                onClick={onClose}
              >
                <X className="h-5 w-5" />
              </button>
              <h2 className="title-font text-gold text-2xl">Join the Voting Community</h2>
              <p className="text-white/70 mt-1">Register to vote and support your favorite artists</p>
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="flex justify-between mb-6">
                <div className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? "bg-gold text-black" : "bg-black/50 border border-gold/30 text-gold/70"}`}
                  >
                    {step > 1 ? <Check className="h-4 w-4" /> : "1"}
                  </div>
                  <div className={`h-1 w-12 ${step >= 2 ? "bg-gold" : "bg-gold/30"}`}></div>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? "bg-gold text-black" : "bg-black/50 border border-gold/30 text-gold/70"}`}
                  >
                    {step > 2 ? <Check className="h-4 w-4" /> : "2"}
                  </div>
                </div>
                <div className="text-gold/60 text-sm">Step {step}/2</div>
              </div>

              <form onSubmit={step === 1 ? nextStep : handleSubmit}>
                <AnimatePresence mode="wait">
                  {step === 1 ? (
                    <motion.div
                      key="step1"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-4"
                    >
                      <div>
                        <label htmlFor="name" className="block text-gold/80 text-sm mb-1">
                          Your Name
                        </label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                            className="pl-10 bg-black/50 border-gold/30 focus:border-gold"
                            placeholder="Enter your full name"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="email" className="block text-gold/80 text-sm mb-1">
                          Email Address
                        </label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gold/60 h-4 w-4" />
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            className="pl-10 bg-black/50 border-gold/30 focus:border-gold"
                            placeholder="your@email.com"
                          />
                        </div>
                      </div>

                      <div className="pt-4">
                        <Button
                          type="button"
                          onClick={nextStep}
                          className="w-full bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-2.5"
                          disabled={!formData.name || !formData.email}
                        >
                          Continue
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-4"
                    >
                      <div className="bg-gold/10 rounded-lg p-4 border border-gold/20">
                        <h3 className="text-gold font-medium mb-2">Benefits of Registration</h3>
                        <ul className="text-white/80 space-y-2">
                          <li className="flex items-start">
                            <Check className="h-4 w-4 text-gold mr-2 mt-1 flex-shrink-0" />
                            <span>Vote for your favorite contestants daily</span>
                          </li>
                          <li className="flex items-start">
                            <Check className="h-4 w-4 text-gold mr-2 mt-1 flex-shrink-0" />
                            <span>Receive notifications about live events</span>
                          </li>
                          <li className="flex items-start">
                            <Check className="h-4 w-4 text-gold mr-2 mt-1 flex-shrink-0" />
                            <span>Get exclusive content from contestants</span>
                          </li>
                        </ul>
                      </div>

                      <div className="flex items-center space-x-2 pt-2">
                        <Checkbox
                          id="receiveUpdates"
                          name="receiveUpdates"
                          checked={formData.receiveUpdates}
                          onCheckedChange={(checked) =>
                            setFormData((prev) => ({ ...prev, receiveUpdates: checked === true }))
                          }
                          className="border-gold data-[state=checked]:bg-gold data-[state=checked]:text-black"
                        />
                        <label htmlFor="receiveUpdates" className="text-sm text-white/80 leading-none">
                          Send me updates about CA$H STRAPPED events and contestants
                        </label>
                      </div>

                      <div className="pt-4 flex gap-3">
                        <Button
                          type="button"
                          onClick={() => setStep(1)}
                          variant="outline"
                          className="flex-1 border-gold/30 text-gold hover:bg-gold/10"
                        >
                          Back
                        </Button>
                        <Button
                          type="submit"
                          className="flex-1 bg-gradient-to-r from-gold/90 to-gold text-black font-medium py-2.5"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin mr-2"></div>
                              Registering...
                            </>
                          ) : (
                            "Complete Registration"
                          )}
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </form>
            </div>

            {/* Footer */}
            <div className="bg-black/50 p-4 text-center text-xs text-white/50">
              By registering, you agree to our Terms of Service and Privacy Policy
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}
