"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Calendar, Clock, MapPin, Ticket, ChevronDown, ChevronUp, Star } from "lucide-react"
import { cn } from "@/lib/utils"
import type { TourLocation } from "./interactive-map"

interface TourTimelineProps {
  locations: TourLocation[]
  selectedLocation: string | null
  onSelectLocation: (locationId: string) => void
  className?: string
}

export function TourTimeline({ locations, selectedLocation, onSelectLocation, className }: TourTimelineProps) {
  const [expandedLocation, setExpandedLocation] = useState<string | null>(null)

  const handleToggleExpand = (locationId: string) => {
    setExpandedLocation(expandedLocation === locationId ? null : locationId)
  }

  // Sort locations by date
  const sortedLocations = [...locations].sort((a, b) => {
    const dateA = new Date(a.date.split(".").reverse().join("-"))
    const dateB = new Date(b.date.split(".").reverse().join("-"))
    return dateA.getTime() - dateB.getTime()
  })

  return (
    <div className={cn("space-y-4", className)}>
      {sortedLocations.map((location, index) => {
        const isSelected = selectedLocation === location.id
        const isExpanded = expandedLocation === location.id
        const isPast = new Date(location.date.split(".").reverse().join("-")) < new Date()

        return (
          <motion.div
            key={location.id}
            className={cn(
              "bg-black/40 backdrop-blur-sm rounded-xl border overflow-hidden transition-all",
              isSelected ? "border-gold" : "border-gold/20",
              isPast && !isSelected && "opacity-70",
            )}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            whileHover={{ y: -5 }}
          >
            <div
              className={cn("p-4 cursor-pointer", isSelected && "bg-gold/10")}
              onClick={() => onSelectLocation(location.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-start gap-3">
                  <div
                    className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                      location.featured
                        ? "bg-gold text-black"
                        : location.upcoming
                          ? "bg-gold/80 text-black"
                          : location.soldOut
                            ? "bg-white/20 text-white/60"
                            : "bg-gold/40 text-black",
                    )}
                  >
                    {location.featured ? <Star className="w-5 h-5" /> : <Calendar className="w-5 h-5" />}
                  </div>

                  <div>
                    <div className="flex items-center">
                      <h3
                        className={cn(
                          "font-medium text-lg",
                          isSelected ? "text-gold" : "text-white",
                          location.soldOut && "line-through opacity-70",
                        )}
                      >
                        {location.city}
                      </h3>

                      {location.featured && (
                        <span className="ml-2 text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-full">Featured</span>
                      )}

                      {location.upcoming && (
                        <span className="ml-2 text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-full">Next Stop</span>
                      )}

                      {location.soldOut && (
                        <span className="ml-2 text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded-full">
                          Sold Out
                        </span>
                      )}
                    </div>

                    <div className="text-white/70 text-sm">{location.venue}</div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="hidden md:block text-right">
                    <div className="text-gold/80 text-sm">{location.date}</div>
                    <div className="text-white/60 text-sm">{location.time}</div>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      handleToggleExpand(location.id)
                    }}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-gold/60 hover:text-gold hover:bg-gold/10"
                  >
                    {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Mobile date/time */}
              <div className="md:hidden mt-2 flex items-center gap-4 text-sm">
                <div className="flex items-center text-gold/80">
                  <Calendar className="w-4 h-4 mr-1" />
                  <span>{location.date}</span>
                </div>
                <div className="flex items-center text-white/60">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>{location.time}</span>
                </div>
              </div>
            </div>

            {/* Expanded content */}
            <AnimatePresence>
              {isExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="border-t border-gold/10 overflow-hidden"
                >
                  <div className="p-4 space-y-4">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center text-gold/80">
                          <MapPin className="w-4 h-4 mr-2" />
                          <span className="font-medium">Venue Information</span>
                        </div>
                        <p className="text-white/70 text-sm">
                          {location.venue} is located in the heart of {location.city}. The venue offers state-of-the-art
                          sound systems and an intimate atmosphere perfect for experiencing CA$H STRAPPED performances.
                        </p>
                      </div>

                      <div className="flex-1 space-y-2">
                        <div className="flex items-center text-gold/80">
                          <Ticket className="w-4 h-4 mr-2" />
                          <span className="font-medium">Ticket Information</span>
                        </div>
                        <p className="text-white/70 text-sm">
                          {location.soldOut
                            ? "This event is sold out. Check our social media for potential last-minute ticket releases."
                            : location.available
                              ? "Tickets are available now. Early bird pricing ends 2 weeks before the event."
                              : "Tickets will be available soon. Join our mailing list to be notified when they go on sale."}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3">
                      <a
                        href={location.ticketsUrl}
                        className={cn(
                          "flex-1 py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-all",
                          location.available && !location.soldOut
                            ? "bg-gradient-to-r from-gold/90 to-gold text-black font-medium"
                            : "bg-white/10 text-white/50 cursor-not-allowed",
                        )}
                        onClick={(e) => (!location.available || location.soldOut) && e.preventDefault()}
                      >
                        <Ticket className="w-4 h-4" />
                        <span>
                          {location.soldOut ? "Sold Out" : location.available ? "Buy Tickets" : "Coming Soon"}
                        </span>
                      </a>

                      <a
                        href={`/tour/${location.id}`}
                        className="flex-1 py-2 px-4 rounded-lg border border-gold/30 text-gold hover:bg-gold/10 flex items-center justify-center gap-2 transition-all"
                      >
                        <MapPin className="w-4 h-4" />
                        <span>Venue Details</span>
                      </a>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )
      })}
    </div>
  )
}
