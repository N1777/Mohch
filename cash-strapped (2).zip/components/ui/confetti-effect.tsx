"use client"

import { useEffect, useRef } from "react"
import confetti from "canvas-confetti"

interface ConfettiEffectProps {
  active: boolean
  onComplete?: () => void
}

export function ConfettiEffect({ active, onComplete }: ConfettiEffectProps) {
  const confettiRef = useRef<HTMLDivElement>(null)
  const hasPlayedRef = useRef(false)

  useEffect(() => {
    if (active && !hasPlayedRef.current && confettiRef.current) {
      hasPlayedRef.current = true

      const rect = confettiRef.current.getBoundingClientRect()
      const x = (rect.left + rect.width / 2) / window.innerWidth
      const y = (rect.top + rect.height / 2) / window.innerHeight

      // Gold-themed confetti
      const customConfetti = confetti.create(undefined, {
        resize: true,
        useWorker: true,
      })

      customConfetti({
        particleCount: 100,
        spread: 70,
        origin: { x, y },
        colors: ["#FFD700", "#FFC107", "#FFEB3B", "#F9A825", "#FFF9C4"],
        shapes: ["star", "circle"],
        scalar: 0.7,
      })

      // Fire a second burst for more effect
      setTimeout(() => {
        customConfetti({
          particleCount: 50,
          spread: 100,
          origin: { x, y },
          colors: ["#FFD700", "#FFC107", "#FFEB3B", "#F9A825", "#FFF9C4"],
          shapes: ["star", "circle"],
          scalar: 0.5,
        })
      }, 200)

      // Reset after animation completes
      setTimeout(() => {
        hasPlayedRef.current = false
        if (onComplete) onComplete()
      }, 2000)
    }
  }, [active, onComplete])

  return <div ref={confettiRef} className="absolute inset-0 pointer-events-none" />
}
