"use client"

import { motion } from "framer-motion"
import { Award, Calendar, Users, Clock } from "lucide-react"

interface VotingStatsProps {
  totalVotes: number
  remainingVotes: number
  isRegistered: boolean
  daysLeft: number
  totalContestants: number
}

export function VotingStats({
  totalVotes,
  remainingVotes,
  isRegistered,
  daysLeft,
  totalContestants,
}: VotingStatsProps) {
  return (
    <motion.div
      className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <div className="p-5">
        <h3 className="text-gold title-font text-xl mb-4">Voting Stats</h3>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-black/50 rounded-lg p-3 border border-gold/10">
            <div className="flex items-center mb-2">
              <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center mr-2">
                <Award className="h-4 w-4 text-gold" />
              </div>
              <span className="text-white/70 text-sm">Total Votes</span>
            </div>
            <p className="text-gold text-2xl font-bold">{totalVotes.toLocaleString()}</p>
          </div>

          <div className="bg-black/50 rounded-lg p-3 border border-gold/10">
            <div className="flex items-center mb-2">
              <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center mr-2">
                <Clock className="h-4 w-4 text-gold" />
              </div>
              <span className="text-white/70 text-sm">Your Votes</span>
            </div>
            {isRegistered ? (
              <p className="text-gold text-2xl font-bold">{remainingVotes} left</p>
            ) : (
              <p className="text-white/50 text-sm">Register to vote</p>
            )}
          </div>

          <div className="bg-black/50 rounded-lg p-3 border border-gold/10">
            <div className="flex items-center mb-2">
              <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center mr-2">
                <Calendar className="h-4 w-4 text-gold" />
              </div>
              <span className="text-white/70 text-sm">Competition</span>
            </div>
            <p className="text-gold text-2xl font-bold">{daysLeft} days</p>
            <p className="text-white/50 text-xs">until finals</p>
          </div>

          <div className="bg-black/50 rounded-lg p-3 border border-gold/10">
            <div className="flex items-center mb-2">
              <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center mr-2">
                <Users className="h-4 w-4 text-gold" />
              </div>
              <span className="text-white/70 text-sm">Contestants</span>
            </div>
            <p className="text-gold text-2xl font-bold">{totalContestants}</p>
            <p className="text-white/50 text-xs">across all categories</p>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
