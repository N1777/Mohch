"use client"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Heart, Award, Play, Share2, TrendingUp, Star } from "lucide-react"
import { OptimizedImage } from "./optimized-image"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { ConfettiEffect } from "./confetti-effect"

interface EnhancedVoteCardProps {
  contestant: {
    id: number
    name: string
    category: string
    city: string
    image: string
    votes: number
    videoUrl?: string
    trending?: boolean
    featured?: boolean
  }
  onVote: (id: number) => void
  isRegistered: boolean
  showRegistrationModal: () => void
  disabled?: boolean
  variant?: "default" | "featured" | "compact"
  className?: string
}

export function EnhancedVoteCard({
  contestant,
  onVote,
  isRegistered,
  showRegistrationModal,
  disabled = false,
  variant = "default",
  className = "",
}: EnhancedVoteCardProps) {
  const [isHovering, setIsHovering] = useState(false)
  const [hasVoted, setHasVoted] = useState(false)
  const [isVoting, setIsVoting] = useState(false)
  const [showConfetti, setShowConfetti] = useState(false)
  const cardRef = useRef<HTMLDivElement>(null)

  const handleVote = () => {
    if (disabled || isVoting || hasVoted) return

    if (!isRegistered) {
      showRegistrationModal()
      return
    }

    setIsVoting(true)

    // Simulate voting animation
    setTimeout(() => {
      onVote(contestant.id)
      setHasVoted(true)
      setIsVoting(false)
      setShowConfetti(true)
    }, 600)
  }

  const isFeatured = variant === "featured" || contestant.featured
  const isCompact = variant === "compact"

  return (
    <motion.div
      ref={cardRef}
      className={cn(
        "group relative overflow-hidden rounded-xl transition-all",
        isFeatured ? "bg-gradient-to-br from-black/90 to-black/70" : "bg-black/80",
        isFeatured ? "border-2 border-gold/40" : "border border-gold/20 hover:border-gold/40",
        disabled && "opacity-70",
        className,
      )}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{
        y: -5,
        boxShadow: isFeatured
          ? "0 15px 30px rgba(0,0,0,0.3), 0 0 20px rgba(255,215,0,0.4)"
          : "0 10px 25px rgba(0,0,0,0.2), 0 0 15px rgba(255,215,0,0.3)",
      }}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Confetti Effect */}
      <ConfettiEffect active={showConfetti} onComplete={() => setShowConfetti(false)} />

      {/* Featured Glow Effect */}
      {isFeatured && (
        <motion.div
          className="absolute inset-0 -z-10 bg-gold/5 rounded-xl blur-xl"
          animate={{
            opacity: [0.5, 0.8, 0.5],
            scale: [0.95, 1.05, 0.95],
          }}
          transition={{
            duration: 4,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />
      )}

      {/* Image Container */}
      <div className={cn("relative overflow-hidden", isCompact ? "aspect-[16/9]" : "aspect-[4/5]")}>
        <OptimizedImage
          src={contestant.image}
          alt={contestant.name}
          fill
          className="object-cover transition-transform duration-500"
          style={{ transform: isHovering ? "scale(1.05)" : "scale(1)" }}
          type="card"
          fallbackCategory={contestant.category}
        />

        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-80"></div>

        {/* Badges */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 items-end">
          {contestant.trending && (
            <div className="bg-gold/90 text-black px-2 py-1 rounded-full flex items-center text-xs font-bold">
              <TrendingUp className="w-3 h-3 mr-1" />
              Trending
            </div>
          )}

          {isFeatured && (
            <div className="bg-black/70 text-gold px-2 py-1 rounded-full flex items-center text-xs font-bold border border-gold/50">
              <Star className="w-3 h-3 mr-1" />
              Featured
            </div>
          )}

          {contestant.votes > 1500 && (
            <div className="bg-black/70 text-gold px-2 py-1 rounded-full flex items-center text-xs font-bold">
              <Award className="w-3 h-3 mr-1" />
              Top Performer
            </div>
          )}
        </div>

        {/* Play Button Overlay */}
        <Link href={`/contestants/${contestant.id}`}>
          <motion.div
            className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            whileHover={{ scale: 1.1 }}
          >
            <div className="w-14 h-14 rounded-full bg-gold/80 flex items-center justify-center">
              <Play className="w-6 h-6 text-black" />
            </div>
          </motion.div>
        </Link>

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="flex justify-between items-end">
            <div>
              <span className="text-xs text-gold/80 accent-font uppercase tracking-wider">{contestant.category}</span>
              <h3 className="title-font text-gold text-xl leading-tight">{contestant.name}</h3>
              <p className="text-white/70 text-sm">{contestant.city}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Vote Section */}
      <div className="p-4">
        {/* Vote Progress Bar */}
        <div className="mb-3">
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              className={cn(
                "h-full",
                isFeatured
                  ? "bg-gradient-to-r from-gold/80 via-gold to-gold/80"
                  : "bg-gradient-to-r from-gold/80 to-gold",
              )}
              initial={{ width: `${Math.min(contestant.votes / 30, 100)}%` }}
              animate={{
                width: hasVoted
                  ? `${Math.min((contestant.votes + 1) / 30, 100)}%`
                  : `${Math.min(contestant.votes / 30, 100)}%`,
              }}
              transition={{ duration: 0.5 }}
            />
          </div>
          <div className="flex justify-between mt-1 text-xs text-white/60">
            <span>{contestant.votes.toLocaleString()} votes</span>
            <span>30k goal</span>
          </div>
        </div>

        {/* Vote Button */}
        <div className="flex gap-3">
          <motion.button
            className={cn(
              "flex-1 py-2.5 rounded-lg flex items-center justify-center gap-2 font-medium transition-all",
              hasVoted
                ? "bg-black border border-gold text-gold"
                : isFeatured
                  ? "bg-gradient-to-r from-gold/90 via-gold to-gold/90 text-black"
                  : "bg-gradient-to-r from-gold/90 to-gold text-black",
            )}
            onClick={handleVote}
            disabled={disabled || isVoting || hasVoted}
            whileTap={{ scale: 0.95 }}
          >
            <AnimatePresence mode="wait">
              {isVoting ? (
                <motion.div
                  key="voting"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"
                />
              ) : hasVoted ? (
                <motion.div
                  key="voted"
                  initial={{ scale: 1.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex items-center"
                >
                  <Heart className="w-5 h-5 mr-1 fill-gold text-gold" />
                  <span>Voted</span>
                </motion.div>
              ) : (
                <motion.div key="vote" className="flex items-center">
                  <Heart className="w-5 h-5 mr-1" />
                  <span>{isRegistered ? "Vote Now" : "Register & Vote"}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>

          <motion.button
            className="w-12 h-12 flex items-center justify-center rounded-lg border border-gold/30 text-gold/80 hover:text-gold hover:border-gold/60 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Share2 className="w-5 h-5" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  )
}
