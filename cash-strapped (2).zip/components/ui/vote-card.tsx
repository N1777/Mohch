"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Heart, Award, Play, Share2, TrendingUp } from "lucide-react"
import { OptimizedImage } from "./optimized-image"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface VoteCardProps {
  contestant: {
    id: number
    name: string
    category: string
    city: string
    image: string
    votes: number
    videoUrl?: string
    trending?: boolean
  }
  onVote: (id: number) => void
  isRegistered: boolean
  showRegistrationModal: () => void
  disabled?: boolean
  size?: "sm" | "md" | "lg"
}

export function VoteCard({
  contestant,
  onVote,
  isRegistered,
  showRegistrationModal,
  disabled = false,
  size = "md",
}: VoteCardProps) {
  const [isHovering, setIsHovering] = useState(false)
  const [hasVoted, setHasVoted] = useState(false)
  const [isVoting, setIsVoting] = useState(false)

  const handleVote = () => {
    if (disabled) return

    if (!isRegistered) {
      showRegistrationModal()
      return
    }

    setIsVoting(true)

    // Simulate voting animation
    setTimeout(() => {
      onVote(contestant.id)
      setHasVoted(true)
      setIsVoting(false)
    }, 600)
  }

  const cardSizeClasses = {
    sm: "max-w-[280px]",
    md: "max-w-[320px]",
    lg: "max-w-[380px]",
  }

  return (
    <motion.div
      className={cn(
        "bg-black/80 rounded-xl overflow-hidden border border-gold/20 hover:border-gold/40 transition-all",
        cardSizeClasses[size],
        disabled && "opacity-70",
      )}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -5, boxShadow: "0 10px 25px rgba(0,0,0,0.2), 0 0 15px rgba(255,215,0,0.3)" }}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Image Container */}
      <div className="relative aspect-[4/5] overflow-hidden">
        <OptimizedImage
          src={contestant.image}
          alt={contestant.name}
          fill
          className="object-cover transition-transform duration-500"
          style={{ transform: isHovering ? "scale(1.05)" : "scale(1)" }}
          type="card"
          fallbackCategory={contestant.category}
        />

        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-80"></div>

        {/* Trending Badge */}
        {contestant.trending && (
          <div className="absolute top-3 right-3 bg-gold/90 text-black px-2 py-1 rounded-full flex items-center text-xs font-bold">
            <TrendingUp className="w-3 h-3 mr-1" />
            Trending
          </div>
        )}

        {/* Play Button Overlay */}
        <Link href={`/contestants/${contestant.id}`}>
          <motion.div
            className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
            whileHover={{ scale: 1.1 }}
          >
            <div className="w-14 h-14 rounded-full bg-gold/80 flex items-center justify-center">
              <Play className="w-6 h-6 text-black" />
            </div>
          </motion.div>
        </Link>

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="flex justify-between items-end">
            <div>
              <span className="text-xs text-gold/80 accent-font uppercase tracking-wider">{contestant.category}</span>
              <h3 className="title-font text-gold text-xl leading-tight">{contestant.name}</h3>
              <p className="text-white/70 text-sm">{contestant.city}</p>
            </div>

            {contestant.votes > 1500 && (
              <div className="flex items-center text-gold bg-black/50 p-1.5 rounded-full">
                <Award className="h-4 w-4" />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Vote Section */}
      <div className="p-4">
        {/* Vote Progress Bar */}
        <div className="mb-3">
          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-gold/80 to-gold"
              initial={{ width: `${Math.min(contestant.votes / 30, 100)}%` }}
              animate={{
                width: hasVoted
                  ? `${Math.min((contestant.votes + 1) / 30, 100)}%`
                  : `${Math.min(contestant.votes / 30, 100)}%`,
              }}
              transition={{ duration: 0.5 }}
            />
          </div>
          <div className="flex justify-between mt-1 text-xs text-white/60">
            <span>{contestant.votes.toLocaleString()} votes</span>
            <span>30k goal</span>
          </div>
        </div>

        {/* Vote Button */}
        <div className="flex gap-3">
          <motion.button
            className={cn(
              "flex-1 py-2.5 rounded-lg flex items-center justify-center gap-2 font-medium transition-all",
              hasVoted ? "bg-black border border-gold text-gold" : "bg-gradient-to-r from-gold/90 to-gold text-black",
            )}
            onClick={handleVote}
            disabled={disabled || isVoting || hasVoted}
            whileTap={{ scale: 0.95 }}
          >
            <AnimatePresence mode="wait">
              {isVoting ? (
                <motion.div
                  key="voting"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"
                />
              ) : hasVoted ? (
                <motion.div
                  key="voted"
                  initial={{ scale: 1.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex items-center"
                >
                  <Heart className="w-5 h-5 mr-1 fill-gold text-gold" />
                  <span>Voted</span>
                </motion.div>
              ) : (
                <motion.div key="vote" className="flex items-center">
                  <Heart className="w-5 h-5 mr-1" />
                  <span>{isRegistered ? "Vote Now" : "Register & Vote"}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>

          <motion.button
            className="w-12 h-12 flex items-center justify-center rounded-lg border border-gold/30 text-gold/80 hover:text-gold hover:border-gold/60 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Share2 className="w-5 h-5" />
          </motion.button>
        </div>
      </div>
    </motion.div>
  )
}
