"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { MapPin, Calendar, Clock, Ticket, Info } from "lucide-react"
import { cn } from "@/lib/utils"

// Tour location data
export interface TourLocation {
  id: string
  city: string
  venue: string
  date: string
  time: string
  coordinates: {
    x: number
    y: number
  }
  ticketsUrl: string
  available: boolean
  featured?: boolean
  upcoming?: boolean
  soldOut?: boolean
}

interface InteractiveMapProps {
  locations: TourLocation[]
  selectedLocation: string | null
  onSelectLocation: (locationId: string) => void
  className?: string
}

export function InteractiveMap({ locations, selectedLocation, onSelectLocation, className }: InteractiveMapProps) {
  const [mapDimensions, setMapDimensions] = useState({ width: 0, height: 0 })
  const mapRef = useRef<HTMLDivElement>(null)
  const [isClient, setIsClient] = useState(false)

  // Set isClient to true on component mount
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Update map dimensions on resize
  useEffect(() => {
    if (!mapRef.current) return

    const updateDimensions = () => {
      if (mapRef.current) {
        setMapDimensions({
          width: mapRef.current.offsetWidth,
          height: mapRef.current.offsetHeight,
        })
      }
    }

    updateDimensions()
    window.addEventListener("resize", updateDimensions)

    return () => {
      window.removeEventListener("resize", updateDimensions)
    }
  }, [isClient])

  // Get the selected location
  const selected = locations.find((loc) => loc.id === selectedLocation) || null

  return (
    <div className={cn("relative w-full", className)}>
      <div
        ref={mapRef}
        className="relative w-full aspect-[4/3] md:aspect-[16/9] bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 overflow-hidden"
      >
        {/* UK Map SVG */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 800 600"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* UK outline - simplified for this example */}
          <path
            d="M350,100 L300,150 L320,200 L280,250 L300,300 L250,350 L300,400 L350,450 L400,500 L450,450 L500,400 L550,350 L500,300 L550,250 L500,200 L450,150 L400,100 L350,100 Z"
            fill="none"
            stroke="rgba(255, 215, 0, 0.3)"
            strokeWidth="2"
          />

          {/* Major cities connections */}
          <path
            d="M320,200 L400,250 L500,300 L450,350 L400,400"
            stroke="rgba(255, 215, 0, 0.2)"
            strokeWidth="1"
            strokeDasharray="5,5"
          />
          <path d="M320,200 L350,300 L400,400" stroke="rgba(255, 215, 0, 0.2)" strokeWidth="1" strokeDasharray="5,5" />
        </svg>

        {/* Location Pins */}
        {isClient &&
          locations.map((location) => {
            // Calculate actual position based on map dimensions
            const x = (location.coordinates.x / 800) * mapDimensions.width
            const y = (location.coordinates.y / 600) * mapDimensions.height

            return (
              <motion.div
                key={location.id}
                className={cn(
                  "absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer",
                  "transition-all duration-300",
                  selectedLocation === location.id ? "z-20" : "z-10",
                )}
                style={{ left: x, top: y }}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileHover={{ scale: 1.2 }}
                onClick={() => onSelectLocation(location.id)}
              >
                <div className={cn("relative", selectedLocation === location.id && "z-20")}>
                  {/* Pulsing circle behind pin */}
                  <div
                    className={cn(
                      "absolute rounded-full -inset-4 animate-pulse-gold",
                      selectedLocation === location.id ? "opacity-100" : "opacity-0",
                    )}
                  ></div>

                  {/* Pin */}
                  <div
                    className={cn(
                      "w-6 h-6 rounded-full flex items-center justify-center",
                      location.featured
                        ? "bg-gold text-black"
                        : location.upcoming
                          ? "bg-gold/80 text-black"
                          : location.soldOut
                            ? "bg-white/20 text-white/60"
                            : "bg-gold/40 text-black",
                      selectedLocation === location.id && "ring-2 ring-gold ring-offset-2 ring-offset-black",
                    )}
                  >
                    <MapPin className="w-3 h-3" />
                  </div>

                  {/* City name */}
                  <div
                    className={cn(
                      "absolute top-full left-1/2 transform -translate-x-1/2 mt-1 whitespace-nowrap",
                      "px-2 py-0.5 rounded text-xs font-medium",
                      selectedLocation === location.id ? "bg-gold text-black" : "bg-black/70 text-gold",
                      location.soldOut && "line-through opacity-70",
                    )}
                  >
                    {location.city}
                  </div>
                </div>
              </motion.div>
            )
          })}

        {/* Map overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none"></div>
      </div>

      {/* Selected Location Details */}
      <AnimatePresence mode="wait">
        {selected && (
          <motion.div
            key={selected.id}
            className="mt-4 bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            <div className="p-5">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="text-gold title-font text-2xl flex items-center">
                    {selected.city}
                    {selected.featured && (
                      <span className="ml-2 text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-full">Featured</span>
                    )}
                    {selected.upcoming && (
                      <span className="ml-2 text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-full">Next Stop</span>
                    )}
                    {selected.soldOut && (
                      <span className="ml-2 text-xs bg-red-500/20 text-red-400 px-2 py-0.5 rounded-full">Sold Out</span>
                    )}
                  </h3>
                  <p className="text-white/70">{selected.venue}</p>
                </div>

                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center text-gold/80">
                    <Calendar className="w-4 h-4 mr-1" />
                    <span>{selected.date}</span>
                  </div>
                  <div className="flex items-center text-gold/80">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{selected.time}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex flex-col sm:flex-row gap-3">
                <a
                  href={selected.ticketsUrl}
                  className={cn(
                    "flex-1 py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-all",
                    selected.available
                      ? "bg-gradient-to-r from-gold/90 to-gold text-black font-medium"
                      : "bg-white/10 text-white/50 cursor-not-allowed",
                  )}
                  onClick={(e) => !selected.available && e.preventDefault()}
                >
                  <Ticket className="w-4 h-4" />
                  <span>{selected.available ? "Buy Tickets" : "Unavailable"}</span>
                </a>

                <a
                  href={`/tour/${selected.id}`}
                  className="flex-1 py-2 px-4 rounded-lg border border-gold/30 text-gold hover:bg-gold/10 flex items-center justify-center gap-2 transition-all"
                >
                  <Info className="w-4 h-4" />
                  <span>Event Details</span>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
