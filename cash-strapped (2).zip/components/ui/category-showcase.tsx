"use client"

import React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { ChevronRight, ChevronLeft } from "lucide-react"
import { cn } from "@/lib/utils"

interface CategoryShowcaseProps {
  categories: {
    id: string
    name: string
    icon: React.ReactNode
    count: number
    color?: string
  }[]
  onSelect: (id: string) => void
  selectedCategory: string
}

export function CategoryShowcase({ categories, onSelect, selectedCategory }: CategoryShowcaseProps) {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null)

  // For mobile scrolling
  const scrollRef = React.useRef<HTMLDivElement>(null)

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -200, behavior: "smooth" })
    }
  }

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 200, behavior: "smooth" })
    }
  }

  return (
    <div className="relative">
      {/* Mobile scroll buttons */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 md:hidden z-10">
        <button
          onClick={scrollLeft}
          className="w-8 h-8 flex items-center justify-center rounded-full bg-black/70 border border-gold/30 text-gold"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </div>

      <div className="absolute right-0 top-1/2 -translate-y-1/2 md:hidden z-10">
        <button
          onClick={scrollRight}
          className="w-8 h-8 flex items-center justify-center rounded-full bg-black/70 border border-gold/30 text-gold"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Categories */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide px-4 md:px-0"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {categories.map((category) => (
          <motion.div
            key={category.id}
            className={cn(
              "flex-shrink-0 relative rounded-xl overflow-hidden cursor-pointer transition-all",
              "border-2",
              selectedCategory === category.id
                ? "border-gold"
                : hoveredCategory === category.id
                  ? "border-gold/50"
                  : "border-gold/20",
              selectedCategory === category.id ? "bg-gold/10" : "bg-black/50",
            )}
            whileHover={{
              y: -5,
              boxShadow: "0 10px 25px rgba(0,0,0,0.2), 0 0 15px rgba(255,215,0,0.3)",
            }}
            onClick={() => onSelect(category.id)}
            onMouseEnter={() => setHoveredCategory(category.id)}
            onMouseLeave={() => setHoveredCategory(null)}
          >
            <div className="p-5 w-48 md:w-56">
              <div className="flex items-center gap-3 mb-3">
                <div
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center",
                    selectedCategory === category.id ? "bg-gold text-black" : "bg-gold/10 text-gold",
                  )}
                >
                  {category.icon}
                </div>
                <div>
                  <h3 className="text-gold font-medium">{category.name}</h3>
                </div>
              </div>

              <div className="text-white/70 text-sm mb-2">{category.count} contestants</div>

              <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-gold/80" style={{ width: `${Math.min(category.count * 10, 100)}%` }} />
              </div>
            </div>

            {/* Highlight effect when selected */}
            {selectedCategory === category.id && (
              <motion.div
                className="absolute inset-0 bg-gold/5"
                initial={{ opacity: 0 }}
                animate={{
                  opacity: [0.5, 0.8, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "reverse",
                }}
              />
            )}
          </motion.div>
        ))}
      </div>
    </div>
  )
}
