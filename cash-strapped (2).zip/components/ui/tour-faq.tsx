"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"

interface FaqItem {
  question: string
  answer: string
}

interface TourFaqProps {
  faqs: FaqItem[]
  className?: string
}

export function TourFaq({ faqs, className }: TourFaqProps) {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null)

  const toggleExpand = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index)
  }

  return (
    <div className={cn("space-y-4", className)}>
      {faqs.map((faq, index) => (
        <motion.div
          key={index}
          className="bg-black/40 backdrop-blur-sm rounded-xl border border-gold/20 overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.05 }}
        >
          <button
            className="w-full p-5 text-left flex items-center justify-between"
            onClick={() => toggleExpand(index)}
          >
            <h3 className="text-gold font-medium text-lg">{faq.question}</h3>
            <div
              className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center transition-colors",
                expandedIndex === index ? "bg-gold/20 text-gold" : "text-gold/60",
              )}
            >
              {expandedIndex === index ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </div>
          </button>

          <AnimatePresence>
            {expandedIndex === index && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="px-5 pb-5 pt-0 border-t border-gold/10">
                  <p className="text-white/70 mt-3">{faq.answer}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      ))}
    </div>
  )
}
