"use client"

import { useState, useEffect } from "react"

interface CountdownTimerProps {
  targetDate: string
}

export default function CountdownTimer({ targetDate }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })

  useEffect(() => {
    const target = new Date(targetDate).getTime()

    const calculateTimeLeft = () => {
      const now = new Date().getTime()
      const difference = target - now

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000),
        })
      } else {
        // If the countdown is over
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
        })
      }
    }

    // Calculate immediately
    calculateTimeLeft()

    // Then set up the interval
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [targetDate])

  return (
    <div className="flex flex-wrap justify-center gap-4 md:gap-6">
      <div className="flex flex-col items-center">
        <div className="countdown-digit w-16 h-16 md:w-24 md:h-24 flex items-center justify-center rounded-lg text-3xl md:text-5xl text-gold gold-pulse relative overflow-hidden">
          <div className="relative z-10">{String(timeLeft.days).padStart(2, "0")}</div>
          <div className="absolute inset-0 bg-gradient-to-br from-black to-black/80 z-0"></div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gold/50"></div>
        </div>
        <span className="text-gold/70 text-sm mt-2 accent-font font-bold">DAYS</span>
      </div>

      <div className="flex flex-col items-center">
        <div className="countdown-digit w-16 h-16 md:w-24 md:h-24 flex items-center justify-center rounded-lg text-3xl md:text-5xl text-gold gold-pulse relative overflow-hidden">
          <div className="relative z-10">{String(timeLeft.hours).padStart(2, "0")}</div>
          <div className="absolute inset-0 bg-gradient-to-br from-black to-black/80 z-0"></div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gold/50"></div>
        </div>
        <span className="text-gold/70 text-sm mt-2 accent-font font-bold">HOURS</span>
      </div>

      <div className="flex flex-col items-center">
        <div className="countdown-digit w-16 h-16 md:w-24 md:h-24 flex items-center justify-center rounded-lg text-3xl md:text-5xl text-gold gold-pulse relative overflow-hidden">
          <div className="relative z-10">{String(timeLeft.minutes).padStart(2, "0")}</div>
          <div className="absolute inset-0 bg-gradient-to-br from-black to-black/80 z-0"></div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gold/50"></div>
        </div>
        <span className="text-gold/70 text-sm mt-2 accent-font font-bold">MINUTES</span>
      </div>

      <div className="flex flex-col items-center">
        <div className="countdown-digit w-16 h-16 md:w-24 md:h-24 flex items-center justify-center rounded-lg text-3xl md:text-5xl text-gold gold-pulse relative overflow-hidden">
          <div className="relative z-10">{String(timeLeft.seconds).padStart(2, "0")}</div>
          <div className="absolute inset-0 bg-gradient-to-br from-black to-black/80 z-0"></div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gold/50"></div>
        </div>
        <span className="text-gold/70 text-sm mt-2 accent-font font-bold">SECONDS</span>
      </div>
    </div>
  )
}
