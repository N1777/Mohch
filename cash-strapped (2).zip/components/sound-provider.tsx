"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type SoundContextType = {
  isSoundEnabled: boolean
  toggleSound: () => void
  playSound: (soundName: string) => void
}

const SoundContext = createContext<SoundContextType | undefined>(undefined)

export function useSoundContext() {
  const context = useContext(SoundContext)
  if (context === undefined) {
    throw new Error("useSoundContext must be used within a SoundProvider")
  }
  return context
}

type SoundProviderProps = {
  children: ReactNode
}

export default function SoundProvider({ children }: SoundProviderProps) {
  const [isSoundEnabled, setIsSoundEnabled] = useState(false)
  const [sounds, setSounds] = useState<Record<string, HTMLAudioElement | null>>({})
  const [soundsLoaded, setSoundsLoaded] = useState(false)

  useEffect(() => {
    // Initialize sounds
    const soundEffects: Record<string, HTMLAudioElement | null> = {
      click: null,
      applause: null,
      transition: null,
    }

    // Check if we're in the browser environment
    if (typeof window !== "undefined") {
      try {
        // Create audio elements
        soundEffects.click = new Audio()
        soundEffects.applause = new Audio()
        soundEffects.transition = new Audio()

        // Set sources
        soundEffects.click.src = "/sounds/click.mp3"
        soundEffects.applause.src = "/sounds/applause.mp3"
        soundEffects.transition.src = "/sounds/transition.mp3"

        // Set volume for all sounds
        Object.values(soundEffects).forEach((sound) => {
          if (sound) {
            sound.volume = 0.5

            // Preload the sounds
            sound.load()

            // Add error handling
            sound.onerror = (e) => {
              console.warn("Error loading sound:", e)
            }
          }
        })

        setSoundsLoaded(true)
      } catch (error) {
        console.error("Error initializing sounds:", error)
      }
    }

    setSounds(soundEffects)

    // Check if sound was previously enabled
    const savedSoundPreference = localStorage.getItem("isSoundEnabled")
    if (savedSoundPreference) {
      setIsSoundEnabled(savedSoundPreference === "true")
    }

    return () => {
      // Cleanup sounds
      Object.values(soundEffects).forEach((sound) => {
        if (sound) {
          sound.pause()
          sound.src = ""
        }
      })
    }
  }, [])

  // Save sound preference when it changes
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("isSoundEnabled", isSoundEnabled.toString())
    }
  }, [isSoundEnabled])

  const toggleSound = () => {
    setIsSoundEnabled((prev) => !prev)
  }

  const playSound = (soundName: string) => {
    if (isSoundEnabled && sounds[soundName] && soundsLoaded) {
      try {
        // Reset the sound to the beginning if it's already playing
        const sound = sounds[soundName]
        if (sound) {
          sound.currentTime = 0
          const playPromise = sound.play()

          if (playPromise !== undefined) {
            playPromise.catch((error) => {
              console.warn("Error playing sound:", error)
            })
          }
        }
      } catch (error) {
        console.warn("Error playing sound:", error)
      }
    }
  }

  return <SoundContext.Provider value={{ isSoundEnabled, toggleSound, playSound }}>{children}</SoundContext.Provider>
}
