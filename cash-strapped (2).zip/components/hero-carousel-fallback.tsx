"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { useSoundContext } from "./sound-provider"
import CountdownTimer from "./countdown-timer"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

export default function HeroCarouselFallback() {
  const [activeSlide, setActiveSlide] = useState(0)
  const { playSound } = useSoundContext()

  const nextSlide = useCallback(() => {
    playSound("transition")
    setActiveSlide((prev) => (prev === 2 ? 0 : prev + 1))
  }, [playSound])

  const prevSlide = useCallback(() => {
    playSound("transition")
    setActiveSlide((prev) => (prev === 0 ? 2 : prev - 1))
  }, [playSound])

  // Auto-rotate slides every 8 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 8000)

    return () => clearInterval(interval)
  }, [nextSlide])

  return (
    <div className="carousel-container hero-section">
      {/* Carousel Slides */}
      <div
        className="carousel-slide flex transition-transform duration-500 h-full"
        style={{ transform: `translateX(-${activeSlide * 100}%)` }}
      >
        {/* Slide 1: Countdown Timer - Leicester Theme */}
        <div className="hero-content min-w-full flex flex-col items-center justify-center px-4 py-16 md:py-24 relative">
          <div className="absolute inset-0 z-0">
            {/* Leicester Theme Gradient */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(45,45,45,1)_0%,_rgba(0,0,0,1)_70%)]">
              {/* City Silhouette */}
              <div
                className="absolute bottom-0 left-0 right-0 h-1/4 bg-black/40"
                style={{
                  maskImage:
                    'url(\'data:image/svg+xml,%3Csvg width="1000" height="100" xmlns="http://www.w3.org/2000/svg"%3E%3Cpath d="M0,100 L50,100 L50,80 L70,80 L70,60 L90,60 L90,80 L110,80 L110,40 L130,40 L130,60 L150,60 L150,30 L170,30 L170,70 L190,70 L190,50 L210,50 L210,80 L230,80 L230,60 L250,60 L250,40 L270,40 L270,70 L290,70 L290,50 L310,50 L310,80 L330,80 L330,60 L350,60 L350,40 L370,40 L370,70 L390,70 L390,30 L410,30 L410,50 L430,50 L430,70 L450,70 L450,40 L470,40 L470,60 L490,60 L490,50 L510,50 L510,70 L530,70 L530,40 L550,40 L550,60 L570,60 L570,80 L590,80 L590,60 L610,60 L610,40 L630,40 L630,70 L650,70 L650,50 L670,50 L670,80 L690,80 L690,60 L710,60 L710,40 L730,40 L730,70 L750,70 L750,30 L770,30 L770,50 L790,50 L790,70 L810,70 L810,40 L830,40 L830,60 L850,60 L850,50 L870,50 L870,70 L890,70 L890,40 L910,40 L910,60 L930,60 L930,80 L950,80 L950,60 L970,60 L970,40 L990,40 L990,100 L0,100 Z" fill="%23000"/%3E%3C/svg%3E\')',
                  maskSize: "cover",
                  maskRepeat: "no-repeat",
                }}
              ></div>
            </div>

            {/* Text overlay for "Leicester, We're Coming To You" */}
            <div className="absolute inset-0 flex items-center justify-center opacity-20">
              <div className="text-[15vw] font-bold text-gold/30 title-font text-center leading-none">
                LEICESTER
                <br />
                WE'RE COMING
              </div>
            </div>

            {/* Vignette effect */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/50"></div>
          </div>

          <div className="text-center max-w-4xl mx-auto relative z-10">
            <h2 className="title-font text-3xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient animate-pulse">
              NEXT BATTLE COMING SOON
            </h2>
            <p className="accent-font text-xl md:text-2xl text-gold/80 mb-8">LEICESTER • CURVE THEATRE</p>

            <CountdownTimer targetDate="2025-06-15T19:00:00" />

            <div className="mt-10">
              <Link href="/tickets">
                <Button className="gold-button text-lg py-6 px-8 animate-bounce" onClick={() => playSound("click")}>
                  Get Tickets Now
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Slide 2: Hall of Fame Stage Theme */}
        <div className="hero-content min-w-full flex flex-col items-center justify-center px-4 py-16 md:py-24 relative">
          <div className="absolute inset-0 z-0">
            {/* Hall of Fame Stage Theme */}
            <div className="absolute inset-0 bg-[linear-gradient(135deg,_rgba(25,25,25,1)_0%,_rgba(10,10,10,1)_100%)]">
              {/* Stage Lights Effect */}
              <div className="absolute top-0 left-1/4 w-1/2 h-1/3 bg-[radial-gradient(circle,_rgba(255,215,0,0.15)_0%,_transparent_70%)]"></div>
              <div className="absolute top-1/4 left-1/6 w-1/3 h-1/3 bg-[radial-gradient(circle,_rgba(255,215,0,0.1)_0%,_transparent_70%)]"></div>
              <div className="absolute top-1/4 right-1/6 w-1/3 h-1/3 bg-[radial-gradient(circle,_rgba(255,215,0,0.1)_0%,_transparent_70%)]"></div>

              {/* Stage Pattern */}
              <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-black to-transparent">
                <div className="absolute inset-x-0 bottom-0 h-px bg-gold/20"></div>
                <div className="absolute inset-x-0 bottom-8 h-px bg-gold/10"></div>
                <div className="absolute inset-x-0 bottom-16 h-px bg-gold/5"></div>
              </div>

              {/* Spotlight Effect */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_30%,_rgba(0,0,0,0.8)_90%)]"></div>
            </div>
          </div>

          <div className="text-center max-w-4xl mx-auto relative z-10">
            <h1 className="logo-text text-6xl md:text-8xl lg:text-9xl mb-6 gold-text-gradient animate-gold-shimmer">
              CA$H STRAPPED
            </h1>
            <p className="accent-font text-xl md:text-2xl text-gold/80 mb-10 max-w-2xl mx-auto">
              THE ULTIMATE UK TALENT ROADSHOW
            </p>

            <div className="flex flex-col md:flex-row gap-4 justify-center mt-8">
              <Link href="/contestants">
                <Button className="gold-button text-lg py-6 px-8 w-full md:w-auto" onClick={() => playSound("click")}>
                  View Contestants
                </Button>
              </Link>
              <Link href="/upload">
                <Button
                  variant="outline"
                  className="gold-outline-button text-lg py-6 px-8 w-full md:w-auto"
                  onClick={() => playSound("click")}
                >
                  Upload Your Performance
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Slide 3: Cash and Gold Theme */}
        <div className="hero-content min-w-full flex flex-col items-center justify-center px-4 py-16 md:py-24 relative">
          <div className="absolute inset-0 z-0">
            {/* Cash and Gold Theme */}
            <div className="absolute inset-0 bg-[linear-gradient(135deg,_rgba(25,25,25,1)_0%,_rgba(10,10,10,1)_100%)]">
              {/* Gold Particles Effect */}
              <div className="absolute inset-0">
                <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 bg-[radial-gradient(circle,_rgba(255,215,0,0.2)_0%,_transparent_60%)]"></div>
                <div className="absolute top-1/3 left-1/3 w-1/3 h-1/3 bg-[radial-gradient(circle,_rgba(255,215,0,0.15)_0%,_transparent_70%)]"></div>

                {/* Gold Coin Pattern */}
                <div
                  className="absolute inset-0 opacity-20"
                  style={{
                    backgroundImage:
                      'url(\'data:image/svg+xml,%3Csvg width="60" height="60" xmlns="http://www.w3.org/2000/svg"%3E%3Ccircle cx="30" cy="30" r="20" stroke="%23FFD700" strokeOpacity="0.3" strokeWidth="1" fill="none"/%3E%3Ccircle cx="30" cy="30" r="10" stroke="%23FFD700" strokeOpacity="0.2" strokeWidth="1" fill="none"/%3E%3C/svg%3E\')',
                    backgroundSize: "60px 60px",
                  }}
                ></div>

                {/* Gold Shimmer Effect */}
                <div className="absolute top-0 left-0 right-0 h-full overflow-hidden">
                  <div
                    className="absolute top-0 left-0 right-0 h-full bg-gradient-to-r from-transparent via-gold/10 to-transparent animate-gold-shimmer"
                    style={{ backgroundSize: "200% 100%" }}
                  ></div>
                </div>
              </div>

              {/* Vignette Effect */}
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_40%,_rgba(0,0,0,0.8)_100%)]"></div>
            </div>
          </div>

          <div className="text-center max-w-4xl mx-auto relative z-10">
            <h2 className="title-font text-3xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient animate-gold-shimmer">
              £50,000 GRAND PRIZE
            </h2>
            <p className="body-font text-xl md:text-2xl text-white mb-8 max-w-2xl mx-auto">
              Show your talent and compete for the ultimate prize. Sponsored by the biggest names in the industry.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
              <div className="bg-black/50 border border-gold/30 p-4 rounded-lg backdrop-blur-sm">
                <h3 className="title-font text-gold text-xl">RAP BATTLES</h3>
                <p className="text-white/70">16 Contestants</p>
              </div>
              <div className="bg-black/50 border border-gold/30 p-4 rounded-lg backdrop-blur-sm">
                <h3 className="title-font text-gold text-xl">DJ SETS</h3>
                <p className="text-white/70">12 Contestants</p>
              </div>
              <div className="bg-black/50 border border-gold/30 p-4 rounded-lg backdrop-blur-sm">
                <h3 className="title-font text-gold text-xl">DANCE CREWS</h3>
                <p className="text-white/70">8 Crews</p>
              </div>
              <div className="bg-black/50 border border-gold/30 p-4 rounded-lg backdrop-blur-sm">
                <h3 className="title-font text-gold text-xl">PRODUCERS</h3>
                <p className="text-white/70">10 Contestants</p>
              </div>
            </div>

            <div className="mt-6">
              <Link href="/register">
                <Button className="gold-button text-lg py-6 px-8 animate-pulse" onClick={() => playSound("click")}>
                  Register to Compete
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Carousel Controls */}
      <div className="absolute left-4 right-4 top-1/2 -translate-y-1/2 flex justify-between z-10">
        <Button
          variant="ghost"
          size="icon"
          className="bg-black/30 hover:bg-black/50 text-gold rounded-full h-12 w-12"
          onClick={prevSlide}
        >
          <ChevronLeft size={24} />
          <span className="sr-only">Previous slide</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="bg-black/30 hover:bg-black/50 text-gold rounded-full h-12 w-12"
          onClick={nextSlide}
        >
          <ChevronRight size={24} />
          <span className="sr-only">Next slide</span>
        </Button>
      </div>

      {/* Carousel Indicators */}
      <div className="absolute bottom-6 left-0 right-0 carousel-indicators z-10">
        {[0, 1, 2].map((index) => (
          <button
            key={index}
            className={`carousel-indicator ${activeSlide === index ? "active" : ""}`}
            onClick={() => {
              playSound("transition")
              setActiveSlide(index)
            }}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
