"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { useSoundContext } from "./sound-provider"
import { Upload, X, Check, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function UploadSection() {
  const [isDragging, setIsDragging] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { playSound } = useSoundContext()
  const { toast } = useToast()

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0]
      handleFile(droppedFile)
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0]
      handleFile(selectedFile)
    }
  }

  const handleFile = (selectedFile: File) => {
    // Check if it's a video file
    if (!selectedFile.type.startsWith("video/")) {
      toast({
        title: "Invalid file type",
        description: "Please upload a video file.",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 100MB)
    if (selectedFile.size > 100 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Maximum file size is 100MB.",
        variant: "destructive",
      })
      return
    }

    setFile(selectedFile)
    playSound("click")
  }

  const handleUpload = () => {
    if (!file) return

    setUploading(true)
    setUploadProgress(0)

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setUploading(false)

          // Show success message
          toast({
            title: "Upload successful!",
            description: "Your video has been uploaded and is being processed.",
            variant: "default",
          })

          playSound("applause")

          // Reset form
          setFile(null)
          setUploadProgress(0)

          return 0
        }
        return prev + 5
      })
    }, 200)
  }

  const cancelUpload = () => {
    setFile(null)
    setUploadProgress(0)
    setUploading(false)
  }

  return (
    <section className="py-16 md:py-24 container mx-auto px-4">
      <div className="text-center mb-12">
        <h2 className="title-font text-4xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient">SUBMIT YOUR TALENT</h2>
        <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto">
          Think you've got what it takes? Upload your performance video and let the audience decide!
        </p>
      </div>

      <div className="max-w-3xl mx-auto">
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${
            isDragging ? "border-gold bg-gold/10" : "border-gold/30 hover:border-gold/50"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {!file ? (
            <div className="py-8">
              <Upload className="h-12 w-12 mx-auto text-gold mb-4" />
              <h3 className="title-font text-gold text-xl mb-2">Drag & Drop Your Video</h3>
              <p className="text-white/70 mb-6">Or click to browse your files (Max size: 100MB)</p>
              <Button className="gold-button" onClick={() => fileInputRef.current?.click()}>
                Select Video
              </Button>
              <input type="file" ref={fileInputRef} className="hidden" accept="video/*" onChange={handleFileInput} />
            </div>
          ) : (
            <div className="py-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gold/20 rounded flex items-center justify-center mr-4">
                    <Check className="h-6 w-6 text-gold" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium truncate max-w-xs">{file.name}</p>
                    <p className="text-white/60 text-sm">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white/70 hover:text-white"
                  onClick={cancelUpload}
                  disabled={uploading}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              {/* Progress bar */}
              <div className="h-2 bg-white/10 rounded-full mb-4 overflow-hidden">
                <div
                  className="h-full bg-gold transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>

              <div className="flex justify-end gap-4">
                <Button variant="outline" className="gold-outline-button" onClick={cancelUpload} disabled={uploading}>
                  Cancel
                </Button>
                <Button className="gold-button" onClick={handleUpload} disabled={uploading}>
                  {uploading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    "Upload Video"
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>

        <div className="mt-8 bg-black/50 border border-gold/30 p-6 rounded-lg">
          <h3 className="title-font text-gold text-xl mb-4">Submission Guidelines</h3>
          <ul className="text-white/80 space-y-2 list-disc pl-5">
            <li>Videos must be under 3 minutes in length</li>
            <li>Content must be original and performed by you</li>
            <li>Ensure good lighting and audio quality</li>
            <li>Submissions will be reviewed before being published</li>
            <li>By uploading, you agree to our terms and conditions</li>
          </ul>
        </div>
      </div>
    </section>
  )
}
