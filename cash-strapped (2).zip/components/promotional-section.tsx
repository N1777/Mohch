"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { OptimizedImage } from "@/components/ui/optimized-image"
import { useSoundContext } from "@/components/sound-provider"
import { Mic, Headphones, Users, Music, Award, TrendingUp, Sparkles } from "lucide-react"
import Link from "next/link"

// Competition categories with details
const CATEGORIES = [
  {
    id: "rap",
    name: "Rap Battles",
    contestants: 16,
    icon: Mic,
    description: "Showcase your lyrical prowess and battle the best MCs in the UK",
    color: "from-amber-500 to-yellow-600",
  },
  {
    id: "dj",
    name: "DJ Sets",
    contestants: 12,
    icon: Headphones,
    description: "Spin, mix and drop beats that will make the crowd move",
    color: "from-yellow-400 to-amber-500",
  },
  {
    id: "dance",
    name: "Dance Crews",
    contestants: 8,
    icon: Users,
    description: "Bring your crew and show off your synchronized moves and style",
    color: "from-amber-400 to-yellow-500",
  },
  {
    id: "producer",
    name: "Producers",
    contestants: 10,
    icon: Music,
    description: "Create original beats and tracks that define the sound of tomorrow",
    color: "from-yellow-500 to-amber-600",
  },
]

// Sponsor logos (would be replaced with actual sponsor images)
const SPONSORS = [
  { name: "Universal Music", logo: "/placeholder.svg?height=60&width=180" },
  { name: "Sony Music", logo: "/placeholder.svg?height=60&width=180" },
  { name: "BBC Radio 1Xtra", logo: "/placeholder.svg?height=60&width=180" },
  { name: "Spotify", logo: "/placeholder.svg?height=60&width=180" },
  { name: "Apple Music", logo: "/placeholder.svg?height=60&width=180" },
]

export default function PromotionalSection() {
  const { playSound } = useSoundContext()
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const sectionRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  // Handle category hover
  const handleCategoryHover = (categoryId: string) => {
    setActiveCategory(categoryId)
    playSound("click")
  }

  // Handle registration button click
  const handleRegisterClick = () => {
    playSound("applause")
  }

  // Intersection observer for animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  return (
    <section
      ref={sectionRef}
      className="py-20 relative overflow-hidden bg-gradient-to-b from-black via-black/95 to-black"
    >
      {/* Animated background particles */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-gold/30"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 10 + 5}px`,
                height: `${Math.random() * 10 + 5}px`,
                animation: `float ${Math.random() * 10 + 10}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 5}s`,
              }}
            />
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Main headline */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="title-font text-4xl md:text-5xl lg:text-6xl mb-4 gold-text-gradient">£50,000 GRAND PRIZE</h2>
          <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto">
            Showcase your talent, get discovered by industry leaders, and compete for the ultimate cash prize
          </p>
        </motion.div>

        {/* Prize and registration section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16 items-center">
          {/* Prize image and details */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: -50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <div className="relative h-[400px] overflow-hidden rounded-lg">
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent z-10"></div>
              <OptimizedImage
                src="/images/gold-prizes-cash.png"
                alt="Gold Prizes and Cash - £50,000 Grand Prize"
                fill
                className="object-cover object-center"
                priority
              />
              {/* Fallback content if image isn't loaded */}
              <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-r from-amber-700 to-yellow-600 z-5">
                <div className="text-center">
                  <h3 className="text-4xl font-bold text-black mb-2">GOLD PRIZES</h3>
                  <h4 className="text-3xl font-bold text-black">&</h4>
                  <h3 className="text-4xl font-bold text-black mt-2">CASH</h3>
                </div>
              </div>

              {/* Prize details overlay */}
              <div className="absolute inset-0 z-20 flex flex-col justify-center p-8">
                <div className="flex items-center mb-4">
                  <Award className="text-gold h-8 w-8 mr-3" />
                  <h3 className="title-font text-3xl text-gold">Grand Prize</h3>
                </div>
                <div className="text-5xl md:text-6xl font-bold mb-4 gold-text-gradient">£50,000</div>
                <ul className="space-y-3">
                  {[
                    "Cash prize for the ultimate winner",
                    "Industry sponsorship deals",
                    "Recording contract opportunities",
                    "National media exposure",
                    "UK tour with leading artists",
                  ].map((benefit, index) => (
                    <li key={index} className="flex items-start">
                      <Sparkles className="text-gold h-5 w-5 mr-2 mt-1 flex-shrink-0" />
                      <span className="text-white/90">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>

          {/* Registration CTA */}
          <motion.div
            className="bg-black/40 backdrop-blur-sm p-8 rounded-lg border border-gold/20"
            initial={{ opacity: 0, x: 50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            <h3 className="title-font text-3xl mb-4 text-gold">Register Now</h3>
            <p className="text-white/80 mb-6">
              Applications are open for all categories. Show us your talent and join the UK's biggest talent
              competition.
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-center">
                <TrendingUp className="text-gold h-5 w-5 mr-3" />
                <span className="text-white/90">Limited spots available - apply early</span>
              </div>
              <div className="flex items-center">
                <TrendingUp className="text-gold h-5 w-5 mr-3" />
                <span className="text-white/90">Auditions in major UK cities</span>
              </div>
              <div className="flex items-center">
                <TrendingUp className="text-gold h-5 w-5 mr-3" />
                <span className="text-white/90">Professional judging panel</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/register" className="flex-1">
                <Button
                  className="w-full py-6 text-lg bg-gold hover:bg-gold/90 text-black font-bold"
                  onClick={handleRegisterClick}
                >
                  Register Now
                </Button>
              </Link>
              <Link href="/tour" className="flex-1">
                <Button variant="outline" className="w-full py-6 text-lg border-gold/50 text-gold hover:bg-gold/10">
                  View Tour Dates
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Categories section */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.7, delay: 0.4 }}
        >
          <h3 className="title-font text-3xl mb-8 text-center text-gold">Competition Categories</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {CATEGORIES.map((category) => {
              const Icon = category.icon
              const isActive = activeCategory === category.id

              return (
                <motion.div
                  key={category.id}
                  className={`bg-black/40 backdrop-blur-sm rounded-lg border border-gold/20 p-6 cursor-pointer transition-all duration-300 ${
                    isActive ? "border-gold scale-105" : "hover:border-gold/50"
                  }`}
                  onMouseEnter={() => handleCategoryHover(category.id)}
                  onMouseLeave={() => setActiveCategory(null)}
                  whileHover={{ y: -5 }}
                >
                  <div
                    className={`w-16 h-16 rounded-full mb-4 flex items-center justify-center bg-gradient-to-r ${category.color}`}
                  >
                    <Icon className="h-8 w-8 text-black" />
                  </div>

                  <h4 className="title-font text-xl mb-2 text-gold">{category.name}</h4>

                  <div className="flex items-center mb-3">
                    <Users className="h-4 w-4 text-gold/80 mr-2" />
                    <span className="text-white/80">{category.contestants} contestants</span>
                  </div>

                  <p className="text-white/70 mb-4">{category.description}</p>

                  <Link href={`/categories/${category.id}`}>
                    <Button variant="link" className="p-0 text-gold hover:text-gold/80">
                      Learn more
                    </Button>
                  </Link>
                </motion.div>
              )
            })}
          </div>
        </motion.div>

        {/* Sponsors section */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.7, delay: 0.5 }}
        >
          <h3 className="title-font text-2xl mb-6 text-gold">Sponsored By Industry Leaders</h3>

          <div className="flex flex-wrap justify-center items-center gap-8">
            {SPONSORS.map((sponsor, index) => (
              <motion.div key={index} className="bg-white/5 backdrop-blur-sm p-4 rounded-lg" whileHover={{ y: -3 }}>
                <OptimizedImage
                  src={sponsor.logo}
                  alt={sponsor.name}
                  width={180}
                  height={60}
                  className="opacity-70 hover:opacity-100 transition-opacity duration-300"
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
