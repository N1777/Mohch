"use client"

import { motion } from "framer-motion"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"

interface EventFiltersProps {
  cities: string[]
  categories: string[]
  selectedCity: string
  selectedCategory: string
  onCityChange: (city: string) => void
  onCategoryChange: (category: string) => void
  onReset: () => void
}

export function EventFilters({
  cities,
  categories,
  selectedCity,
  selectedCategory,
  onCityChange,
  onCategoryChange,
  onReset,
}: EventFiltersProps) {
  const formatLabel = (value: string) => {
    if (value === "all") return "All"
    return value
  }

  return (
    <motion.div
      initial={{ height: 0, opacity: 0 }}
      animate={{ height: "auto", opacity: 1 }}
      exit={{ height: 0, opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="px-4 pb-4 border-t border-gold/10"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
        {/* Cities */}
        <div>
          <label className="block text-gold/80 text-sm mb-2">City</label>
          <div className="flex flex-wrap gap-2">
            {cities.map((city) => (
              <button
                key={city}
                className={cn(
                  "px-3 py-1.5 rounded-full text-sm transition-colors",
                  selectedCity === city
                    ? "bg-gold text-black font-medium"
                    : "bg-black/50 border border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                )}
                onClick={() => onCityChange(city)}
              >
                {formatLabel(city)}
              </button>
            ))}
          </div>
        </div>

        {/* Categories */}
        <div>
          <label className="block text-gold/80 text-sm mb-2">Category</label>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                className={cn(
                  "px-3 py-1.5 rounded-full text-sm transition-colors",
                  selectedCategory === category
                    ? "bg-gold text-black font-medium"
                    : "bg-black/50 border border-gold/30 text-gold/70 hover:text-gold hover:border-gold/50",
                )}
                onClick={() => onCategoryChange(category)}
              >
                {formatLabel(category)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Reset Filters */}
      {(selectedCity !== "all" || selectedCategory !== "all") && (
        <div className="mt-4 flex justify-end">
          <button className="text-gold/70 hover:text-gold text-sm flex items-center gap-1" onClick={onReset}>
            <X className="h-3 w-3" />
            Reset all filters
          </button>
        </div>
      )}
    </motion.div>
  )
}
