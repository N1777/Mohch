"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { Clock, MapPin, Ticket, ChevronDown, ChevronUp, Star } from "lucide-react"
import { OptimizedImage } from "@/components/ui/optimized-image"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useSoundContext } from "@/components/sound-provider"
import type { ScheduleEvent } from "@/data/schedule-data"

interface EventCardProps {
  event: ScheduleEvent
  variant?: "default" | "compact"
}

export function EventCard({ event, variant = "default" }: EventCardProps) {
  const [expanded, setExpanded] = useState(false)
  const { playSound } = useSoundContext()
  const isCompact = variant === "compact"

  const toggleExpanded = () => {
    playSound("click")
    setExpanded(!expanded)
  }

  // Format time for display
  const formatTime = (time: string): string => {
    // Convert 24-hour format to 12-hour format
    const [hours, minutes] = time.split(":")
    const hour = Number.parseInt(hours, 10)
    const ampm = hour >= 12 ? "PM" : "AM"
    const hour12 = hour % 12 || 12
    return `${hour12}:${minutes} ${ampm}`
  }

  return (
    <motion.div
      className={cn(
        "bg-black/40 backdrop-blur-sm rounded-xl border overflow-hidden transition-all",
        event.featured ? "border-gold/40" : "border-gold/20",
        !isCompact && "hover:border-gold/40",
      )}
      whileHover={isCompact ? {} : { y: -5 }}
    >
      {!isCompact && (
        <div className="relative aspect-video">
          <OptimizedImage
            src={event.image}
            alt={event.title}
            fill
            className="object-cover"
            type="card"
            fallbackCategory={event.category}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>

          {/* Category Badge */}
          <div className="absolute top-3 left-3 bg-black/70 text-gold px-2 py-1 rounded-full text-xs font-medium">
            {event.category}
          </div>

          {/* Featured Badge */}
          {event.featured && (
            <div className="absolute top-3 right-3 bg-gold/90 text-black px-2 py-1 rounded-full flex items-center text-xs font-bold">
              <Star className="w-3 h-3 mr-1" />
              Featured
            </div>
          )}

          {/* Sold Out Badge */}
          {event.soldOut && (
            <div className="absolute top-3 right-3 bg-red-500/90 text-white px-2 py-1 rounded-full text-xs font-bold">
              Sold Out
            </div>
          )}

          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h3 className="text-gold text-xl font-medium line-clamp-2">{event.title}</h3>
          </div>
        </div>
      )}

      <div className="p-4">
        {isCompact && (
          <div className="flex justify-between items-start mb-3">
            <h3 className="text-gold text-lg font-medium">{event.title}</h3>
            {event.featured && (
              <div className="bg-gold/20 text-gold px-2 py-0.5 rounded-full flex items-center text-xs">
                <Star className="w-3 h-3 mr-1" />
                Featured
              </div>
            )}
          </div>
        )}

        <div className="space-y-2 mb-4">
          <div className="flex items-center text-white/80">
            <Clock className="w-4 h-4 text-gold/70 mr-2 flex-shrink-0" />
            <span>
              {formatTime(event.time)} - {formatTime(event.endTime)}
            </span>
          </div>

          <div className="flex items-center text-white/80">
            <MapPin className="w-4 h-4 text-gold/70 mr-2 flex-shrink-0" />
            <span>
              {event.venue}, {event.city}
            </span>
          </div>

          {event.price && (
            <div className="flex items-center text-white/80">
              <Ticket className="w-4 h-4 text-gold/70 mr-2 flex-shrink-0" />
              <span>{event.price}</span>
            </div>
          )}
        </div>

        {!isCompact && (
          <div className="mb-4">
            <button className="flex items-center text-gold/70 hover:text-gold text-sm" onClick={toggleExpanded}>
              {expanded ? (
                <>
                  <ChevronUp className="w-4 h-4 mr-1" />
                  Hide details
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4 mr-1" />
                  Show details
                </>
              )}
            </button>

            {expanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-3 text-white/70 text-sm"
              >
                <p>{event.description}</p>
                <p className="mt-2 text-white/60 text-xs">{event.address}</p>
              </motion.div>
            )}
          </div>
        )}

        <div className="flex gap-2">
          <Link
            href={event.ticketUrl}
            className={cn("flex-1", isCompact && "text-center")}
            onClick={() => playSound("click")}
          >
            <Button
              className={cn(
                "w-full",
                event.soldOut
                  ? "bg-white/10 text-white/50 cursor-not-allowed"
                  : "bg-gradient-to-r from-gold/90 to-gold text-black font-medium",
              )}
              disabled={event.soldOut}
            >
              {event.soldOut ? "Sold Out" : "Buy Tickets"}
            </Button>
          </Link>

          {!isCompact && (
            <Link href={`/schedule/${event.id}`} onClick={() => playSound("click")}>
              <Button variant="outline" className="border-gold/30 text-gold hover:bg-gold/10">
                Details
              </Button>
            </Link>
          )}
        </div>
      </div>
    </motion.div>
  )
}
