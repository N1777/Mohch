"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Calendar } from "lucide-react"
import { EventCard } from "./event-card"
import { cn } from "@/lib/utils"
import type { ScheduleEvent } from "@/data/schedule-data"

interface ScheduleCalendarViewProps {
  events: ScheduleEvent[]
}

export function ScheduleCalendarView({ events }: ScheduleCalendarViewProps) {
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date())
  const [calendarDays, setCalendarDays] = useState<Date[]>([])
  const [selectedDate, setSelectedDate] = useState<string | null>(null)
  const [eventsOnSelectedDate, setEventsOnSelectedDate] = useState<ScheduleEvent[]>([])

  // Generate calendar days for the current month
  useEffect(() => {
    const days: Date[] = []
    const year = currentMonth.getFullYear()
    const month = currentMonth.getMonth()

    // Get the first day of the month
    const firstDay = new Date(year, month, 1)
    // Get the last day of the month
    const lastDay = new Date(year, month + 1, 0)

    // Get the day of the week for the first day (0 = Sunday, 1 = Monday, etc.)
    const firstDayOfWeek = firstDay.getDay()

    // Add days from the previous month to fill the first week
    for (let i = firstDayOfWeek; i > 0; i--) {
      const prevMonthDay = new Date(year, month, 1 - i)
      days.push(prevMonthDay)
    }

    // Add all days of the current month
    for (let i = 1; i <= lastDay.getDate(); i++) {
      days.push(new Date(year, month, i))
    }

    // Add days from the next month to complete the last week
    const remainingDays = 7 - (days.length % 7)
    if (remainingDays < 7) {
      for (let i = 1; i <= remainingDays; i++) {
        days.push(new Date(year, month + 1, i))
      }
    }

    setCalendarDays(days)

    // If no date is selected, select today or the first event date
    if (!selectedDate) {
      const today = new Date().toISOString().split("T")[0]
      const hasEventToday = events.some((event) => event.date === today)

      if (hasEventToday) {
        setSelectedDate(today)
      } else if (events.length > 0) {
        // Find the closest future event
        const futureEvents = events.filter((event) => event.date >= today)
        if (futureEvents.length > 0) {
          futureEvents.sort((a, b) => a.date.localeCompare(b.date))
          setSelectedDate(futureEvents[0].date)
        } else {
          // If no future events, select the most recent past event
          const sortedEvents = [...events].sort((a, b) => b.date.localeCompare(a.date))
          setSelectedDate(sortedEvents[0].date)
        }
      }
    }
  }, [currentMonth, events, selectedDate])

  // Update events for selected date
  useEffect(() => {
    if (selectedDate) {
      const filteredEvents = events.filter((event) => event.date === selectedDate)
      setEventsOnSelectedDate(filteredEvents)
    } else {
      setEventsOnSelectedDate([])
    }
  }, [selectedDate, events])

  // Navigate to previous month
  const goToPreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1))
  }

  // Navigate to next month
  const goToNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1))
  }

  // Format date as YYYY-MM-DD
  const formatDateString = (date: Date): string => {
    return date.toISOString().split("T")[0]
  }

  // Check if a date has events
  const hasEvents = (date: Date): boolean => {
    const dateString = formatDateString(date)
    return events.some((event) => event.date === dateString)
  }

  // Get event count for a date
  const getEventCount = (date: Date): number => {
    const dateString = formatDateString(date)
    return events.filter((event) => event.date === dateString).length
  }

  // Check if a date is in the current month
  const isCurrentMonth = (date: Date): boolean => {
    return date.getMonth() === currentMonth.getMonth()
  }

  // Check if a date is today
  const isToday = (date: Date): boolean => {
    const today = new Date()
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    )
  }

  // Check if a date is selected
  const isSelected = (date: Date): boolean => {
    return formatDateString(date) === selectedDate
  }

  // Format month and year
  const formatMonthYear = (date: Date): string => {
    return date.toLocaleDateString("en-US", { month: "long", year: "numeric" })
  }

  // Day names
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  return (
    <div className="bg-black/40 backdrop-blur-md rounded-xl border border-gold/20 overflow-hidden">
      {/* Calendar Header */}
      <div className="p-4 border-b border-gold/10 flex items-center justify-between">
        <h2 className="text-gold text-xl flex items-center">
          <Calendar className="w-5 h-5 mr-2" />
          {formatMonthYear(currentMonth)}
        </h2>
        <div className="flex items-center space-x-2">
          <button
            className="w-8 h-8 flex items-center justify-center rounded-full text-gold/70 hover:text-gold hover:bg-gold/10"
            onClick={goToPreviousMonth}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            className="w-8 h-8 flex items-center justify-center rounded-full text-gold/70 hover:text-gold hover:bg-gold/10"
            onClick={goToNextMonth}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-7 md:divide-x md:divide-gold/10">
        {/* Calendar Grid */}
        <div className="col-span-1 md:col-span-5">
          {/* Day Names */}
          <div className="grid grid-cols-7 border-b border-gold/10">
            {dayNames.map((day) => (
              <div key={day} className="p-2 text-center text-gold/70 text-sm font-medium">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Days */}
          <div className="grid grid-cols-7 auto-rows-fr">
            {calendarDays.map((date, index) => {
              const dateString = formatDateString(date)
              const hasEventsOnDate = hasEvents(date)
              const eventCount = getEventCount(date)

              return (
                <button
                  key={index}
                  className={cn(
                    "p-2 border-b border-r border-gold/10 relative transition-colors min-h-[80px] md:min-h-[100px]",
                    !isCurrentMonth(date) && "opacity-40",
                    isSelected(date) && "bg-gold/10",
                    hasEventsOnDate && !isSelected(date) && "hover:bg-gold/5",
                  )}
                  onClick={() => hasEventsOnDate && setSelectedDate(dateString)}
                  disabled={!hasEventsOnDate}
                >
                  <div
                    className={cn(
                      "w-8 h-8 flex items-center justify-center rounded-full mx-auto mb-1",
                      isToday(date) && "bg-gold/20 text-gold",
                      isSelected(date) && "bg-gold text-black font-medium",
                    )}
                  >
                    {date.getDate()}
                  </div>

                  {hasEventsOnDate && (
                    <div className="text-center">
                      <span
                        className={cn(
                          "inline-block px-2 py-0.5 rounded-full text-xs",
                          isSelected(date) ? "bg-gold/30 text-white" : "bg-gold/20 text-gold/90",
                        )}
                      >
                        {eventCount} event{eventCount !== 1 ? "s" : ""}
                      </span>
                    </div>
                  )}
                </button>
              )
            })}
          </div>
        </div>

        {/* Events for Selected Date */}
        <div className="col-span-1 md:col-span-2 p-4 md:p-0">
          <div className="md:p-4 border-b border-gold/10">
            <h3 className="text-gold font-medium">
              {selectedDate
                ? new Date(selectedDate).toLocaleDateString("en-US", {
                    weekday: "long",
                    month: "long",
                    day: "numeric",
                  })
                : "Select a date"}
            </h3>
          </div>

          <div className="md:p-4 space-y-4 max-h-[500px] overflow-y-auto">
            <AnimatePresence mode="wait">
              {eventsOnSelectedDate.length > 0 ? (
                <motion.div
                  key={selectedDate}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-4"
                >
                  {eventsOnSelectedDate.map((event) => (
                    <EventCard key={event.id} event={event} variant="compact" />
                  ))}
                </motion.div>
              ) : (
                <motion.div
                  key="no-events"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="text-center py-8"
                >
                  <p className="text-white/70">No events scheduled for this date.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  )
}
