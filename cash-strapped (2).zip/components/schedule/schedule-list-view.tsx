"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { EventCard } from "./event-card"
import type { ScheduleEvent } from "@/data/schedule-data"

interface ScheduleListViewProps {
  events: ScheduleEvent[]
}

export function ScheduleListView({ events }: ScheduleListViewProps) {
  const [groupedEvents, setGroupedEvents] = useState<Record<string, ScheduleEvent[]>>({})
  const [sortedDates, setSortedDates] = useState<string[]>([])

  // Group events by date
  useEffect(() => {
    const grouped: Record<string, ScheduleEvent[]> = {}

    // Group events by date
    events.forEach((event) => {
      if (!grouped[event.date]) {
        grouped[event.date] = []
      }
      grouped[event.date].push(event)
    })

    // Sort events within each date by time
    Object.keys(grouped).forEach((date) => {
      grouped[date].sort((a, b) => a.time.localeCompare(b.time))
    })

    setGroupedEvents(grouped)

    // Sort dates
    const dates = Object.keys(grouped).sort()
    setSortedDates(dates)
  }, [events])

  // Format date for display
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    })
  }

  // Check if date is in the future
  const isFutureDate = (dateString: string): boolean => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const date = new Date(dateString)
    return date >= today
  }

  return (
    <div className="space-y-8">
      {sortedDates.map((date, dateIndex) => (
        <motion.div
          key={date}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: dateIndex * 0.05 }}
        >
          <div className="flex items-center mb-4">
            <div className="flex-1 h-px bg-gold/20"></div>
            <h3 className="text-gold font-medium px-4 flex items-center">
              {formatDate(date)}
              {isFutureDate(date) && (
                <span className="ml-2 text-xs bg-gold/20 text-gold px-2 py-0.5 rounded-full">Upcoming</span>
              )}
            </h3>
            <div className="flex-1 h-px bg-gold/20"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {groupedEvents[date].map((event, eventIndex) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.1 + eventIndex * 0.05 }}
              >
                <EventCard event={event} />
              </motion.div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  )
}
