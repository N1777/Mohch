"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Volume2, VolumeX, Menu, X } from "lucide-react"
import { useSoundContext } from "./sound-provider"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { isSoundEnabled, toggleSound } = useSoundContext()

  return (
    <header className="border-b border-gold/20 py-4 px-4 md:px-6 relative z-50">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center">
          <span className="logo-text text-3xl md:text-4xl gold-text-gradient font-bold">CA$H STRAPPED</span>
        </Link>

        {/* Mobile menu button */}
        <button className="md:hidden text-gold" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/" className="text-gold/80 hover:text-gold transition-colors accent-font">
            Home
          </Link>
          <Link href="/contestants" className="text-gold/80 hover:text-gold transition-colors accent-font">
            Contestants
          </Link>
          <Link href="/upload" className="text-gold/80 hover:text-gold transition-colors accent-font">
            Upload
          </Link>
          <Link href="/vote" className="text-gold/80 hover:text-gold transition-colors accent-font">
            Vote
          </Link>
          <Link href="/schedule" className="text-gold/80 hover:text-gold transition-colors accent-font">
            Schedule
          </Link>
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          <Button onClick={toggleSound} variant="ghost" className="text-gold hover:bg-gold/10">
            {isSoundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
          </Button>

          <Link href="/login">
            <Button variant="outline" className="gold-outline-button">
              Login
            </Button>
          </Link>

          <Link href="/register">
            <Button className="gold-button">Register</Button>
          </Link>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-black border-b border-gold/20 py-4 z-50">
          <nav className="container mx-auto flex flex-col space-y-4 px-4">
            <Link
              href="/"
              className="text-gold/80 hover:text-gold transition-colors accent-font py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/contestants"
              className="text-gold/80 hover:text-gold transition-colors accent-font py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Contestants
            </Link>
            <Link
              href="/upload"
              className="text-gold/80 hover:text-gold transition-colors accent-font py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Upload
            </Link>
            <Link
              href="/vote"
              className="text-gold/80 hover:text-gold transition-colors accent-font py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Vote
            </Link>
            <Link
              href="/schedule"
              className="text-gold/80 hover:text-gold transition-colors accent-font py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Schedule
            </Link>

            <div className="flex items-center space-x-4 pt-2">
              <Button onClick={toggleSound} variant="ghost" className="text-gold hover:bg-gold/10">
                {isSoundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
              </Button>

              <Link href="/login" className="flex-1">
                <Button variant="outline" className="gold-outline-button w-full" onClick={() => setIsMenuOpen(false)}>
                  Login
                </Button>
              </Link>
            </div>

            <Link href="/register" className="pt-2">
              <Button className="gold-button w-full" onClick={() => setIsMenuOpen(false)}>
                Register
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
