import { Button } from "@/components/ui/button"
import { Mic, Music, Users, Calendar } from "lucide-react"
import Link from "next/link"

export default function EventInfo() {
  return (
    <section className="py-16 md:py-24 container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="title-font text-4xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient">
          THE ULTIMATE TALENT SHOWDOWN
        </h2>
        <p className="body-font text-lg md:text-xl text-gold/80 max-w-3xl mx-auto">
          CA$H STRAPPED brings together the UK's most talented artists in a high-stakes competition across multiple
          cities.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <div className="bg-black/50 border border-gold/30 p-6 rounded-lg text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center">
            <Mic className="text-gold h-8 w-8" />
          </div>
          <h3 className="title-font text-gold text-xl mb-3">RAP BATTLES</h3>
          <p className="text-white/70 mb-4">
            Witness lyrical warfare as MCs battle head-to-head with their best bars and flows.
          </p>
          <Link href="/categories/rap">
            <Button variant="outline" className="gold-outline-button">
              Learn More
            </Button>
          </Link>
        </div>

        <div className="bg-black/50 border border-gold/30 p-6 rounded-lg text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center">
            <Music className="text-gold h-8 w-8" />
          </div>
          <h3 className="title-font text-gold text-xl mb-3">DJ COMPETITIONS</h3>
          <p className="text-white/70 mb-4">
            DJs showcase their mixing skills, creativity and crowd control in epic showdowns.
          </p>
          <Link href="/categories/dj">
            <Button variant="outline" className="gold-outline-button">
              Learn More
            </Button>
          </Link>
        </div>

        <div className="bg-black/50 border border-gold/30 p-6 rounded-lg text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center">
            <Users className="text-gold h-8 w-8" />
          </div>
          <h3 className="title-font text-gold text-xl mb-3">DANCE CREWS</h3>
          <p className="text-white/70 mb-4">
            Dance crews battle it out with jaw-dropping choreography and stunning performances.
          </p>
          <Link href="/categories/dance">
            <Button variant="outline" className="gold-outline-button">
              Learn More
            </Button>
          </Link>
        </div>

        <div className="bg-black/50 border border-gold/30 p-6 rounded-lg text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gold/10 flex items-center justify-center">
            <Calendar className="text-gold h-8 w-8" />
          </div>
          <h3 className="title-font text-gold text-xl mb-3">UK TOUR</h3>
          <p className="text-white/70 mb-4">
            Touring major UK cities including Leicester, London, Manchester, Birmingham and more.
          </p>
          <Link href="/tour-dates">
            <Button variant="outline" className="gold-outline-button">
              View Schedule
            </Button>
          </Link>
        </div>
      </div>

      <div className="mt-16 text-center">
        <Link href="/about">
          <Button className="gold-button text-lg py-6 px-8">About CA$H STRAPPED</Button>
        </Link>
      </div>
    </section>
  )
}
