"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { useSoundContext } from "./sound-provider"
import CountdownTimer from "./countdown-timer"
import Link from "next/link"
import { ChevronLeft, ChevronRight, Star, Award, Music, PoundSterling, Trophy } from "lucide-react"
import { OptimizedImage } from "./ui/optimized-image"

export default function HeroCarousel() {
  const [activeSlide, setActiveSlide] = useState(0)
  const [isHovering, setIsHovering] = useState(false)
  const { playSound } = useSoundContext()

  const nextSlide = useCallback(() => {
    playSound("transition")
    setActiveSlide((prev) => (prev === 2 ? 0 : prev + 1))
  }, [playSound])

  const prevSlide = useCallback(() => {
    playSound("transition")
    setActiveSlide((prev) => (prev === 0 ? 2 : prev - 1))
  }, [playSound])

  // Auto-rotate slides every 8 seconds, but only if not hovering
  useEffect(() => {
    if (isHovering) return

    const interval = setInterval(() => {
      nextSlide()
    }, 8000)

    return () => clearInterval(interval)
  }, [nextSlide, isHovering])

  return (
    <div
      className="carousel-container hero-section"
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Carousel Slides */}
      <div
        className="carousel-slide flex transition-transform duration-700 h-full"
        style={{ transform: `translateX(-${activeSlide * 100}%)` }}
      >
        {/* Slide 1: Leicester Image with Countdown Timer */}
        <div className="hero-content min-w-full flex flex-col items-center justify-center relative">
          {/* Gold frame border */}
          <div className="absolute inset-4 border-2 border-gold/30 z-20 pointer-events-none"></div>

          {/* Corner decorations */}
          <div className="absolute top-8 left-8 w-16 h-16 border-t-2 border-l-2 border-gold z-20 pointer-events-none"></div>
          <div className="absolute top-8 right-8 w-16 h-16 border-t-2 border-r-2 border-gold z-20 pointer-events-none"></div>
          <div className="absolute bottom-8 left-8 w-16 h-16 border-b-2 border-l-2 border-gold z-20 pointer-events-none"></div>
          <div className="absolute bottom-8 right-8 w-16 h-16 border-b-2 border-r-2 border-gold z-20 pointer-events-none"></div>

          {/* Principal Image with hover effect */}
          <div className="w-full h-[80vh] relative overflow-hidden">
            <div className="absolute inset-0 bg-black/5 z-10 image-texture"></div>
            <OptimizedImage
              src="/images/leicester-background.png"
              alt="Leicester City - Next Battle Location"
              fill
              priority
              className="transition-transform duration-10000 hover:scale-110 image-zoom"
              type="hero"
            />

            {/* Floating elements */}
            <div className="absolute top-1/4 left-1/4 transform -translate-x-1/2 -translate-y-1/2 z-10">
              <Star className="text-gold h-8 w-8 animate-float opacity-80" />
            </div>
            <div className="absolute top-1/3 right-1/4 transform translate-x-1/2 -translate-y-1/2 z-10">
              <Star className="text-gold h-6 w-6 animate-float-delay opacity-60" />
            </div>

            {/* Text Overlay - Positioned at the bottom */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/70 to-transparent pt-32 pb-16 px-4 z-10">
              <div className="container mx-auto text-center max-w-4xl">
                <h2 className="title-font text-3xl md:text-5xl lg:text-6xl mb-6 gold-text-gradient animate-pulse">
                  NEXT BATTLE COMING SOON
                </h2>
                <p className="accent-font text-xl md:text-2xl text-gold/80 mb-8">LEICESTER • CURVE THEATRE</p>

                <CountdownTimer targetDate="2025-06-15T19:00:00" />

                <div className="mt-10">
                  <Link href="/tickets">
                    <Button
                      className="gold-button text-lg py-6 px-8 animate-bounce relative group overflow-hidden"
                      onClick={() => playSound("click")}
                    >
                      <span className="relative z-10">Get Tickets Now</span>
                      <span className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Slide 2: Hall of Fame Stage Image */}
        <div className="hero-content min-w-full flex flex-col items-center justify-center relative">
          {/* Gold frame border */}
          <div className="absolute inset-4 border-2 border-gold/30 z-20 pointer-events-none"></div>

          {/* Corner decorations */}
          <div className="absolute top-8 left-8 w-16 h-16 border-t-2 border-l-2 border-gold z-20 pointer-events-none"></div>
          <div className="absolute top-8 right-8 w-16 h-16 border-t-2 border-r-2 border-gold z-20 pointer-events-none"></div>
          <div className="absolute bottom-8 left-8 w-16 h-16 border-b-2 border-l-2 border-gold z-20 pointer-events-none"></div>
          <div className="absolute bottom-8 right-8 w-16 h-16 border-b-2 border-r-2 border-gold z-20 pointer-events-none"></div>

          {/* Principal Image with hover effect */}
          <div className="w-full h-[80vh] relative overflow-hidden">
            <div className="absolute inset-0 bg-black/5 z-10 image-texture"></div>
            <OptimizedImage
              src="/images/hall-of-fame-stage.png"
              alt="Hall of Fame Stage"
              fill
              className="transition-transform duration-10000 hover:scale-110 image-zoom"
              type="hero"
            />

            {/* Floating elements */}
            <div className="absolute bottom-1/4 left-1/3 transform -translate-x-1/2 translate-y-1/2 z-10">
              <Music className="text-gold h-8 w-8 animate-float opacity-80" />
            </div>
            <div className="absolute top-1/3 right-1/3 transform translate-x-1/2 -translate-y-1/2 z-10">
              <Music className="text-gold h-6 w-6 animate-float-delay opacity-60" />
            </div>

            {/* Text Overlay - Positioned in the center with gold accents */}
            <div className="absolute inset-0 flex items-center justify-center z-10">
              <div className="relative">
                {/* Gold accent lines */}
                <div className="absolute -top-8 -left-8 w-16 h-16 border-t-2 border-l-2 border-gold"></div>
                <div className="absolute -top-8 -right-8 w-16 h-16 border-t-2 border-r-2 border-gold"></div>
                <div className="absolute -bottom-8 -left-8 w-16 h-16 border-b-2 border-l-2 border-gold"></div>
                <div className="absolute -bottom-8 -right-8 w-16 h-16 border-b-2 border-r-2 border-gold"></div>

                <div className="bg-black/60 backdrop-blur-sm p-8 rounded-lg max-w-4xl mx-4 border border-gold/20">
                  <h1 className="logo-text text-6xl md:text-8xl lg:text-9xl mb-6 gold-text-gradient animate-gold-shimmer">
                    CA$H STRAPPED
                  </h1>
                  <p className="accent-font text-xl md:text-2xl text-gold/80 mb-10 max-w-2xl mx-auto">
                    THE ULTIMATE UK TALENT ROADSHOW
                  </p>

                  <div className="flex flex-col md:flex-row gap-4 justify-center mt-8">
                    <Link href="/contestants">
                      <Button
                        className="gold-button text-lg py-6 px-8 w-full md:w-auto relative group overflow-hidden"
                        onClick={() => playSound("click")}
                      >
                        <span className="relative z-10">View Contestants</span>
                        <span className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
                      </Button>
                    </Link>
                    <Link href="/upload">
                      <Button
                        variant="outline"
                        className="gold-outline-button text-lg py-6 px-8 w-full md:w-auto relative group overflow-hidden"
                        onClick={() => playSound("click")}
                      >
                        <span className="relative z-10">Upload Your Performance</span>
                        <span className="absolute inset-0 bg-gold/10 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>

            {/* Stage lighting effects */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none z-10"></div>
          </div>
        </div>

        {/* Slide 3: Gold Prizes and Cash Image - ENHANCED */}
        <div className="hero-content min-w-full flex flex-col items-center justify-center relative">
          {/* Gold frame border - Enhanced with animation */}
          <div className="absolute inset-4 border-2 border-gold/50 z-20 pointer-events-none animate-pulse"></div>

          {/* Corner decorations - Enhanced with larger size */}
          <div className="absolute top-8 left-8 w-20 h-20 border-t-4 border-l-4 border-gold z-20 pointer-events-none"></div>
          <div className="absolute top-8 right-8 w-20 h-20 border-t-4 border-r-4 border-gold z-20 pointer-events-none"></div>
          <div className="absolute bottom-8 left-8 w-20 h-20 border-b-4 border-l-4 border-gold z-20 pointer-events-none"></div>
          <div className="absolute bottom-8 right-8 w-20 h-20 border-b-4 border-r-4 border-gold z-20 pointer-events-none"></div>

          {/* Principal Image with enhanced display */}
          <div className="w-full h-[80vh] relative overflow-hidden">
            {/* Gold-themed overlay effect */}
            <div className="absolute inset-0 bg-gradient-to-b from-gold/5 to-black/5 mix-blend-overlay z-10"></div>

            {/* High-quality optimized image */}
            <OptimizedImage
              src="/images/gold-prizes-cash.jpg"
              alt="£50,000 Grand Prize - Gold Trophies and Cash"
              fill
              priority
              className="transition-transform duration-10000 hover:scale-110 image-zoom brightness-115 contrast-115 saturate-125"
              type="hero"
              quality={100}
              objectPosition="center"
            />

            {/* Floating elements - Strategic positioning */}
            <div className="absolute top-[15%] right-[22%] transform translate-x-1/2 -translate-y-1/2 z-10">
              <Trophy className="text-gold h-12 w-12 animate-float opacity-90 drop-shadow-[0_0_15px_rgba(255,215,0,0.7)]" />
            </div>
            <div className="absolute bottom-[25%] left-[20%] transform -translate-x-1/2 translate-y-1/2 z-10">
              <PoundSterling className="text-gold h-12 w-12 animate-float-delay opacity-90 drop-shadow-[0_0_15px_rgba(255,215,0,0.7)]" />
            </div>

            {/* Enhanced prize highlight overlay */}
            <div className="absolute top-[10%] left-0 right-0 z-20 text-center">
              <div className="inline-block bg-black/60 backdrop-blur-md px-12 py-6 rounded-full border-2 border-gold animate-pulse">
                <h2 className="title-font text-4xl md:text-6xl lg:text-7xl gold-text-gradient animate-gold-shimmer text-shadow-dark font-bold">
                  £50,000 GRAND PRIZE
                </h2>
              </div>
            </div>

            {/* Prize details - Positioned strategically for better impact */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/70 to-transparent pb-20 pt-32 px-4 z-10">
              <div className="container mx-auto text-center max-w-5xl">
                <p className="body-font text-xl md:text-2xl lg:text-3xl text-white mb-8 max-w-3xl mx-auto text-shadow-dark font-semibold">
                  <span className="text-gold">Showcase your talent</span> and win life-changing prizes
                </p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
                  <div className="bg-black/80 border-2 border-gold/60 p-4 rounded-lg backdrop-blur-md transform transition-transform hover:scale-105 hover:border-gold">
                    <h3 className="title-font text-gold text-xl md:text-2xl">RAP BATTLES</h3>
                    <p className="text-white/90">16 Contestants</p>
                    <div className="mt-2 flex justify-center">
                      <Trophy className="text-gold h-5 w-5" />
                    </div>
                  </div>
                  <div className="bg-black/80 border-2 border-gold/60 p-4 rounded-lg backdrop-blur-md transform transition-transform hover:scale-105 hover:border-gold">
                    <h3 className="title-font text-gold text-xl md:text-2xl">DJ SETS</h3>
                    <p className="text-white/90">12 Contestants</p>
                    <div className="mt-2 flex justify-center">
                      <Music className="text-gold h-5 w-5" />
                    </div>
                  </div>
                  <div className="bg-black/80 border-2 border-gold/60 p-4 rounded-lg backdrop-blur-md transform transition-transform hover:scale-105 hover:border-gold">
                    <h3 className="title-font text-gold text-xl md:text-2xl">DANCE CREWS</h3>
                    <p className="text-white/90">8 Crews</p>
                    <div className="mt-2 flex justify-center">
                      <Star className="text-gold h-5 w-5" />
                    </div>
                  </div>
                  <div className="bg-black/80 border-2 border-gold/60 p-4 rounded-lg backdrop-blur-md transform transition-transform hover:scale-105 hover:border-gold">
                    <h3 className="title-font text-gold text-xl md:text-2xl">PRODUCERS</h3>
                    <p className="text-white/90">10 Contestants</p>
                    <div className="mt-2 flex justify-center">
                      <Award className="text-gold h-5 w-5" />
                    </div>
                  </div>
                </div>

                <div className="flex flex-col md:flex-row gap-4 justify-center mt-8">
                  <Link href="/register">
                    <Button
                      className="gold-button text-lg py-6 px-10 animate-pulse relative group overflow-hidden"
                      onClick={() => playSound("click")}
                    >
                      <PoundSterling className="mr-2 h-5 w-5" />
                      <span className="relative z-10">Register to Compete</span>
                      <span className="absolute inset-0 bg-white/20 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
                    </Button>
                  </Link>
                  <Link href="/sponsors">
                    <Button
                      variant="outline"
                      className="gold-outline-button text-lg py-6 px-10 group overflow-hidden"
                      onClick={() => playSound("click")}
                    >
                      <span className="relative z-10">View Sponsorship Details</span>
                      <span className="absolute inset-0 bg-gold/10 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Carousel Controls - Enhanced with gold accents */}
      <div className="absolute left-4 right-4 top-1/2 -translate-y-1/2 flex justify-between z-30">
        <Button
          variant="ghost"
          size="icon"
          className="bg-black/30 hover:bg-black/50 text-gold rounded-full h-12 w-12 border border-gold/30 hover:border-gold transition-colors"
          onClick={prevSlide}
        >
          <ChevronLeft size={24} />
          <span className="sr-only">Previous slide</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="bg-black/30 hover:bg-black/50 text-gold rounded-full h-12 w-12 border border-gold/30 hover:border-gold transition-colors"
          onClick={nextSlide}
        >
          <ChevronRight size={24} />
          <span className="sr-only">Next slide</span>
        </Button>
      </div>

      {/* Carousel Indicators - Enhanced with gold accents */}
      <div className="absolute bottom-6 left-0 right-0 carousel-indicators z-30">
        {[0, 1, 2].map((index) => (
          <button
            key={index}
            className={`carousel-indicator ${activeSlide === index ? "active" : ""}`}
            onClick={() => {
              playSound("transition")
              setActiveSlide(index)
            }}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
